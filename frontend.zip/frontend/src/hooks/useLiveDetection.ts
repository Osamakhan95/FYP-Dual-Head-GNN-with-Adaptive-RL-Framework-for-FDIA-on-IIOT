import { useRef, useState, useCallback, useEffect } from 'react';

const WS_BASE = 'ws://127.0.0.1:8000';

// ---- Types ----

export interface LiveAnomaly {
  node_id: string;
  confidence: number;
  severity: string;
}

export interface LiveStats {
  total_processed: number;
  total_attacks: number;
  total_normal: number;
  running_accuracy: number | null;
  tp: number;
  tn: number;
  fp: number;
  fn: number;
  progress: number;
}

export interface LivePrediction {
  row: number;
  timestamp: string;
  is_attack: boolean;
  system_probability: number;
  actual_label: number | null;
  correct: boolean | null;
  anomaly_count: number;
  anomalies: LiveAnomaly[];
  sensor_snapshot: Record<string, number>;
  stats: LiveStats;
}

export interface LiveStatus {
  state: string;
  message?: string;
  speed?: number;
  dataset?: string;
  total_rows?: number;
  sensors?: number;
  row?: number;
  total_processed?: number;
  total_attacks?: number;
  total_normal?: number;
  running_accuracy?: number | null;
}

export type ConnectionState = 'disconnected' | 'connecting' | 'connected' | 'streaming' | 'stopped' | 'finished' | 'error';

// ---- Hook ----

export function useLiveDetection() {
  const wsRef = useRef<WebSocket | null>(null);
  const [connectionState, setConnectionState] = useState<ConnectionState>('disconnected');
  const [lastPrediction, setLastPrediction] = useState<LivePrediction | null>(null);
  const [predictions, setPredictions] = useState<LivePrediction[]>([]);
  const [status, setStatus] = useState<LiveStatus | null>(null);
  const [error, setError] = useState<string>('');
  const [speed, setSpeedState] = useState(1.0);

  // Keep recent N predictions to avoid memory issues
  const MAX_HISTORY = 200;

  const connect = useCallback(() => {
    const token = localStorage.getItem('token');
    if (!token) {
      setError('Not authenticated. Please log in.');
      setConnectionState('error');
      return;
    }

    // Close existing connection
    if (wsRef.current) {
      wsRef.current.close();
    }

    setConnectionState('connecting');
    setError('');

    const ws = new WebSocket(`${WS_BASE}/model/live?token=${token}`);
    wsRef.current = ws;

    ws.onopen = () => {
      setConnectionState('connected');
      setError('');
    };

    ws.onmessage = (event) => {
      try {
        const msg = JSON.parse(event.data);

        if (msg.type === 'prediction') {
          const pred: LivePrediction = msg.data;
          setLastPrediction(pred);
          setPredictions(prev => {
            const next = [pred, ...prev];
            return next.length > MAX_HISTORY ? next.slice(0, MAX_HISTORY) : next;
          });
        } else if (msg.type === 'status') {
          const s: LiveStatus = msg.data;
          setStatus(s);
          if (s.state === 'streaming') {
            setConnectionState('streaming');
          } else if (s.state === 'stopped') {
            setConnectionState('stopped');
          } else if (s.state === 'finished') {
            setConnectionState('finished');
          } else if (s.state === 'connected') {
            setConnectionState('connected');
          } else if (s.state === 'reset') {
            setConnectionState('connected');
            setLastPrediction(null);
            setPredictions([]);
          } else if (s.state === 'speed_changed' && s.speed) {
            setSpeedState(s.speed);
          }
        } else if (msg.type === 'error') {
          setError(msg.message || 'Unknown error');
        }
      } catch {
        // ignore parse errors
      }
    };

    ws.onerror = () => {
      setError('WebSocket connection error');
      setConnectionState('error');
    };

    ws.onclose = (e) => {
      if (e.code === 4001 || e.code === 4003) {
        setError('Authentication failed. Please log in again.');
      }
      setConnectionState('disconnected');
      wsRef.current = null;
    };
  }, []);

  const disconnect = useCallback(() => {
    if (wsRef.current) {
      wsRef.current.close();
      wsRef.current = null;
    }
    setConnectionState('disconnected');
  }, []);

  const sendAction = useCallback((action: string, extra?: Record<string, unknown>) => {
    if (wsRef.current && wsRef.current.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ action, ...extra }));
    }
  }, []);

  const start = useCallback((opts?: { speed?: number; row?: number }) => {
    sendAction('start', opts);
  }, [sendAction]);

  const stop = useCallback(() => {
    sendAction('stop');
  }, [sendAction]);

  const setSpeed = useCallback((value: number) => {
    setSpeedState(value);
    sendAction('speed', { value });
  }, [sendAction]);

  const reset = useCallback(() => {
    sendAction('reset');
    setLastPrediction(null);
    setPredictions([]);
  }, [sendAction]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (wsRef.current) {
        wsRef.current.close();
      }
    };
  }, []);

  return {
    connectionState,
    lastPrediction,
    predictions,
    status,
    error,
    speed,
    connect,
    disconnect,
    start,
    stop,
    setSpeed,
    reset,
  };
}
