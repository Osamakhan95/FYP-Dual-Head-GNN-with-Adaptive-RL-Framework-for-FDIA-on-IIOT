import React, { useState, useEffect, useCallback } from 'react';
import {
  Shield,
  AlertTriangle,
  Activity,
  Bell,
  LogOut,
  BarChart3,
  Network,
  Menu,
  X,
  TrendingUp,
  Clock,
  CheckCircle2,
  Upload,
  RefreshCw,
  Radio,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { modelService } from '../services/api';
import { useNavigate } from 'react-router-dom';
import { DetectionWorkspace } from '../components/DetectionWorkspace';
import type { Anomaly, ModelStats } from '../types';

export const UserDashboard: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [activeTab, setActiveTab] = useState('overview');

  // Data states
  const [stats, setStats] = useState<ModelStats | null>(null);
  const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchDashboardData = useCallback(async () => {
    try {
      setLoading(true);
      const [statsData, anomalyData] = await Promise.all([
        modelService.getStats(),
        modelService.getAnomalies(20, false),
      ]);
      setStats(statsData);
      setAnomalies(anomalyData);
    } catch (err) {
      console.error('Error fetching dashboard data:', err);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    fetchDashboardData();
  }, [fetchDashboardData]);


  const handleResolveAnomaly = async (id: number) => {
    try {
      await modelService.resolveAnomaly(id);
      setAnomalies(prev => prev.filter(a => a.id !== id));
      if (stats) setStats({ ...stats, unresolved_anomalies: stats.unresolved_anomalies - 1, resolved_anomalies: stats.resolved_anomalies + 1 });
    } catch (err) {
      console.error('Error resolving anomaly:', err);
    }
  };

  // ---- Helpers ----
  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-600 text-white';
      case 'high': return 'bg-red-100 text-red-700 border border-red-200';
      case 'medium': return 'bg-amber-100 text-amber-700 border border-amber-200';
      case 'low': return 'bg-blue-100 text-blue-700 border border-blue-200';
      default: return 'bg-gray-100 text-gray-700';
    }
  };

  const getSeverityDot = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-500';
      case 'high': return 'bg-orange-500';
      case 'medium': return 'bg-amber-500';
      case 'low': return 'bg-blue-500';
      default: return 'bg-gray-400';
    }
  };

  // ---- Render Sections ----

  const renderOverview = () => (
    <div className="space-y-8">
      {/* Stats Row */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard icon={<Shield className="w-6 h-6 text-white" />} label="Total Anomalies" value={stats?.total_anomalies ?? 0} bg="bg-sky-500" />
        <StatCard icon={<AlertTriangle className="w-6 h-6 text-white" />} label="Unresolved" value={stats?.unresolved_anomalies ?? 0} bg="bg-red-500" />
        <StatCard icon={<Bell className="w-6 h-6 text-white" />} label="Today" value={stats?.anomalies_today ?? 0} bg="bg-amber-500" />
        <StatCard icon={<TrendingUp className="w-6 h-6 text-white" />} label="Model Accuracy" value={`${stats?.model_accuracy ?? 0}%`} bg="bg-emerald-500" />
      </div>

      {/* Quick Upload + Recent Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
        {/* Quick CSV Upload */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <Upload className="w-5 h-5 text-sky-600" /> Quick Prediction
          </h3>
          <div className="border-2 border-dashed rounded-xl p-6 text-center border-gray-300 bg-gray-50">
            <p className="text-sm text-gray-600 mb-2">Use the dedicated Upload tab for batch prediction.</p>
            <p className="text-xs text-gray-400 mb-4">Includes CSV upload, processing, summary metrics, and row-level results.</p>
            <button
              onClick={() => setActiveTab('upload')}
              className="px-4 py-2 bg-sky-600 text-white text-sm rounded-lg hover:bg-sky-700"
            >
              Open Upload & Predict
            </button>
          </div>
        </div>

        {/* Recent Anomalies */}
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4 flex items-center gap-2">
            <AlertTriangle className="w-5 h-5 text-red-500" /> Recent Alerts
          </h3>
          {anomalies.length === 0 ? (
            <div className="text-center py-8 text-gray-400">
              <CheckCircle2 className="w-10 h-10 mx-auto mb-2" />
              <p>No unresolved anomalies</p>
            </div>
          ) : (
            <div className="space-y-2 max-h-[280px] overflow-y-auto pr-1">
              {anomalies.slice(0, 8).map(a => (
                <div key={a.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className={`w-2.5 h-2.5 rounded-full ${getSeverityDot(a.severity)}`} />
                    <div>
                      <p className="text-sm font-medium text-gray-900">{a.node_id}</p>
                      <p className="text-xs text-gray-500">{new Date(a.detected_at).toLocaleString()}</p>
                    </div>
                  </div>
                  <span className={`px-2 py-0.5 rounded-full text-xs font-medium ${getSeverityColor(a.severity)}`}>
                    {a.severity}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Severity Breakdown */}
      {stats && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Severity Breakdown</h3>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {Object.entries(stats.severity_counts).map(([sev, count]) => (
              <div key={sev} className="text-center p-4 rounded-xl bg-gray-50">
                <div className={`w-4 h-4 rounded-full mx-auto mb-2 ${getSeverityDot(sev)}`} />
                <p className="text-2xl font-bold text-gray-900">{count}</p>
                <p className="text-sm text-gray-500 capitalize">{sev}</p>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Top Attacked Nodes */}
      {stats && stats.top_attacked_nodes.length > 0 && (
        <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Top Attacked Nodes</h3>
          <div className="space-y-3">
            {stats.top_attacked_nodes.map((node) => {
              const maxCount = stats.top_attacked_nodes[0]?.count || 1;
              return (
                <div key={node.node} className="flex items-center gap-4">
                  <span className="text-sm font-medium text-gray-700 w-20">{node.node}</span>
                  <div className="flex-1 bg-gray-100 rounded-full h-3 overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-sky-500 to-sky-600 rounded-full transition-all"
                      style={{ width: `${(node.count / maxCount) * 100}%` }}
                    />
                  </div>
                  <span className="text-sm font-semibold text-gray-900 w-10 text-right">{node.count}</span>
                </div>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );

  const renderUploadPredict = () => (
    <DetectionWorkspace view="upload" theme="light" onAfterPredict={fetchDashboardData} />
  );

  const renderTopology = () => (
    <DetectionWorkspace view="topology" theme="light" onAfterPredict={fetchDashboardData} />
  );

  const renderAlerts = () => (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-100">
        <div className="p-6 border-b border-gray-100 flex items-center justify-between">
          <div>
            <h3 className="text-lg font-semibold text-gray-900">Anomaly Alerts</h3>
            <p className="text-sm text-gray-500">{anomalies.length} unresolved anomalies</p>
          </div>
          <button onClick={fetchDashboardData} className="flex items-center gap-2 px-4 py-2 text-sm text-sky-600 hover:bg-sky-50 rounded-lg">
            <RefreshCw className="w-4 h-4" /> Refresh
          </button>
        </div>
        {anomalies.length === 0 ? (
          <div className="p-12 text-center text-gray-400">
            <CheckCircle2 className="w-12 h-12 mx-auto mb-3" />
            <p className="font-medium">All Clear!</p>
            <p className="text-sm">No unresolved anomalies at this time.</p>
          </div>
        ) : (
          <div className="divide-y divide-gray-100">
            {anomalies.map(a => (
              <div key={a.id} className="p-5 hover:bg-gray-50 flex items-center justify-between">
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-lg ${
                    a.severity === 'critical' || a.severity === 'high' ? 'bg-red-100' :
                    a.severity === 'medium' ? 'bg-amber-100' : 'bg-blue-100'
                  }`}>
                    <AlertTriangle className={`w-5 h-5 ${
                      a.severity === 'critical' || a.severity === 'high' ? 'text-red-600' :
                      a.severity === 'medium' ? 'text-amber-600' : 'text-blue-600'
                    }`} />
                  </div>
                  <div>
                    <p className="font-medium text-gray-900">FDI Attack — {a.node_id}</p>
                    <div className="flex items-center gap-3 mt-1">
                      <span className="text-xs text-gray-500 flex items-center gap-1"><Clock className="w-3 h-3" /> {new Date(a.detected_at).toLocaleString()}</span>
                      <span className="text-xs text-gray-500">Confidence: {(a.confidence * 100).toFixed(1)}%</span>
                    </div>
                  </div>
                </div>
                <div className="flex items-center gap-3">
                  <span className={`px-3 py-1 rounded-full text-xs font-semibold ${getSeverityColor(a.severity)}`}>
                    {a.severity.toUpperCase()}
                  </span>
                  <button
                    onClick={() => handleResolveAnomaly(a.id)}
                    className="px-3 py-1.5 text-xs font-medium text-emerald-600 bg-emerald-50 hover:bg-emerald-100 rounded-lg transition"
                  >
                    Resolve
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-64' : 'w-20'} bg-slate-900 text-white transition-all duration-300 flex flex-col`}>
        <div className="p-4 border-b border-slate-700 flex items-center justify-between">
          {sidebarOpen && (
            <div className="flex items-center gap-3">
              <Shield className="w-8 h-8 text-sky-400" />
              <span className="font-bold text-lg">IIoT Security</span>
            </div>
          )}
          <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-slate-800 rounded-lg">
            {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>

        <nav className="flex-1 p-4 space-y-2">
          {[
            { id: 'overview', icon: BarChart3, label: 'Overview' },
            { id: 'upload', icon: Upload, label: 'Upload & Predict' },
            { id: 'topology', icon: Network, label: 'Network Topology' },
            { id: 'alerts', icon: Bell, label: 'Alerts' },
          ].map(item => (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors ${
                activeTab === item.id ? 'bg-sky-600 text-white' : 'text-slate-300 hover:bg-slate-800'
              }`}
            >
              <item.icon className="w-5 h-5" />
              {sidebarOpen && <span>{item.label}</span>}
            </button>
          ))}
          {/* Live Detection Button */}
          <button
            onClick={() => navigate('/live')}
            className="w-full flex items-center gap-3 px-4 py-3 rounded-lg transition-colors text-red-400 hover:bg-red-500/10 border border-red-500/30 mt-4"
          >
            <Radio className="w-5 h-5" />
            {sidebarOpen && (
              <span className="flex items-center gap-2">
                Live Detection
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              </span>
            )}
          </button>
        </nav>

        <div className="p-4 border-t border-slate-700">
          <button onClick={logout} className="w-full flex items-center gap-3 px-4 py-3 text-slate-300 hover:bg-slate-800 rounded-lg transition-colors">
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        <header className="bg-white shadow-sm border-b border-gray-200 px-8 py-4">
          <div className="flex items-center justify-between">
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Security Dashboard</h1>
              <p className="text-sm text-gray-500">Welcome back, {user?.full_name}</p>
            </div>
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2 px-3 py-1.5 bg-emerald-100 text-emerald-700 rounded-full text-sm">
                <Activity className="w-4 h-4" />
                System Online
              </div>
              <button className="relative p-2 text-gray-500 hover:text-gray-700 hover:bg-gray-100 rounded-lg" onClick={() => setActiveTab('alerts')}>
                <Bell className="w-6 h-6" />
                {anomalies.length > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs w-5 h-5 flex items-center justify-center rounded-full">
                    {anomalies.length > 9 ? '9+' : anomalies.length}
                  </span>
                )}
              </button>
              <div className="w-10 h-10 bg-sky-600 rounded-full flex items-center justify-center text-white font-semibold">
                {user?.full_name?.charAt(0).toUpperCase()}
              </div>
            </div>
          </div>
        </header>

        <div className="p-8">
          {loading ? <LoadingSpinner /> : (
            <>
              {activeTab === 'overview' && renderOverview()}
              {activeTab === 'upload' && renderUploadPredict()}
              {activeTab === 'topology' && renderTopology()}
              {activeTab === 'alerts' && renderAlerts()}
            </>
          )}
        </div>
      </main>
    </div>
  );
};

// ---- Helper Components ----
const StatCard: React.FC<{ icon: React.ReactNode; label: string; value: string | number; bg: string }> = ({ icon, label, value, bg }) => (
  <div className="bg-white rounded-xl shadow-sm border border-gray-100 p-6">
    <div className="flex items-center justify-between">
      <div>
        <p className="text-sm font-medium text-gray-500">{label}</p>
        <p className="text-3xl font-bold text-gray-900 mt-1">{value}</p>
      </div>
      <div className={`p-3 rounded-lg ${bg}`}>{icon}</div>
    </div>
  </div>
);

const LoadingSpinner: React.FC = () => (
  <div className="flex items-center justify-center h-64">
    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-sky-600"></div>
  </div>
);
