import React, { useMemo } from 'react';
import {
  Shield,
  AlertTriangle,
  Activity,
  Bell,
  LogOut,
  Radio,
  Wifi,
  WifiOff,
  Play,
  Pause,
  RotateCcw,
  Gauge,
  TrendingUp,
  Clock,
  Zap,
  Menu,
  X,
  ArrowLeft,
  ChevronDown,
  ChevronUp,
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { useLiveDetection, type LivePrediction } from '../hooks/useLiveDetection';
import { useNavigate } from 'react-router-dom';
import { useState } from 'react';

export const LiveDetectionPage: React.FC = () => {
  const { user, logout } = useAuth();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [showAllPredictions, setShowAllPredictions] = useState(false);

  const {
    connectionState,
    lastPrediction,
    predictions,
    status,
    error,
    speed,
    connect,
    disconnect,
    start,
    stop,
    setSpeed,
    reset,
  } = useLiveDetection();

  // Derived state
  const isConnected = connectionState !== 'disconnected' && connectionState !== 'error';
  const isStreaming = connectionState === 'streaming';
  const stats = lastPrediction?.stats;

  // Attack rate for recent predictions
  const recentAttackRate = useMemo(() => {
    const recent = predictions.slice(0, 50);
    if (recent.length === 0) return 0;
    return Math.round((recent.filter(p => p.is_attack).length / recent.length) * 100);
  }, [predictions]);

  // Recent anomalies (deduplicated by node)
  const recentAnomalies = useMemo(() => {
    const nodeMap = new Map<string, { node_id: string; confidence: number; severity: string; count: number }>();
    predictions.slice(0, 30).forEach(p => {
      p.anomalies.forEach(a => {
        const existing = nodeMap.get(a.node_id);
        if (existing) {
          existing.count++;
          existing.confidence = Math.max(existing.confidence, a.confidence);
        } else {
          nodeMap.set(a.node_id, { ...a, count: 1 });
        }
      });
    });
    return Array.from(nodeMap.values()).sort((a, b) => b.count - a.count).slice(0, 10);
  }, [predictions]);

  // Connection status colors
  const getStatusInfo = () => {
    switch (connectionState) {
      case 'streaming': return { color: 'bg-emerald-500', text: 'Live Streaming', pulse: true };
      case 'connected': return { color: 'bg-blue-500', text: 'Connected (Ready)', pulse: false };
      case 'stopped': return { color: 'bg-amber-500', text: 'Paused', pulse: false };
      case 'finished': return { color: 'bg-purple-500', text: 'Completed', pulse: false };
      case 'connecting': return { color: 'bg-amber-500', text: 'Connecting...', pulse: true };
      case 'error': return { color: 'bg-red-500', text: 'Error', pulse: false };
      default: return { color: 'bg-gray-400', text: 'Disconnected', pulse: false };
    }
  };

  const statusInfo = getStatusInfo();

  const getSeverityColor = (severity: string) => {
    switch (severity) {
      case 'critical': return 'bg-red-600 text-white';
      case 'high': return 'bg-orange-500/20 text-orange-400';
      case 'medium': return 'bg-amber-500/20 text-amber-400';
      case 'low': return 'bg-blue-500/20 text-blue-400';
      default: return 'bg-gray-500/20 text-gray-400';
    }
  };

  // Attack probability gauge
  const attackProb = lastPrediction?.system_probability ?? 0;
  const gaugeRotation = attackProb * 180 - 90; // -90° to 90°

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 flex">
      {/* Sidebar */}
      <aside className={`${sidebarOpen ? 'w-72' : 'w-20'} bg-slate-900/50 backdrop-blur-xl border-r border-slate-700/50 transition-all duration-300 flex flex-col`}>
        <div className="p-6 border-b border-slate-700/50">
          <div className="flex items-center justify-between">
            {sidebarOpen ? (
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center shadow-lg shadow-red-500/25">
                  <Radio className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h1 className="font-bold text-white text-lg">Live Detection</h1>
                  <p className="text-xs text-slate-400">Real-time FDI Monitor</p>
                </div>
              </div>
            ) : (
              <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-500 to-orange-600 flex items-center justify-center mx-auto">
                <Radio className="w-6 h-6 text-white" />
              </div>
            )}
            <button onClick={() => setSidebarOpen(!sidebarOpen)} className="p-2 hover:bg-slate-800 rounded-lg text-slate-400 hover:text-white transition-colors">
              {sidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
            </button>
          </div>
        </div>

        {/* Controls Panel */}
        <div className="flex-1 p-4 space-y-4">
          {sidebarOpen && (
            <>
              {/* Connection Status */}
              <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50">
                <div className="flex items-center gap-3 mb-3">
                  <div className={`w-3 h-3 rounded-full ${statusInfo.color} ${statusInfo.pulse ? 'animate-pulse' : ''}`} />
                  <span className="text-sm font-medium text-white">{statusInfo.text}</span>
                </div>

                {/* Connect / Disconnect */}
                {!isConnected ? (
                  <button onClick={connect} className="w-full py-2.5 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-xl font-medium text-sm hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center justify-center gap-2">
                    <Wifi className="w-4 h-4" /> Connect to Server
                  </button>
                ) : (
                  <button onClick={disconnect} className="w-full py-2.5 bg-slate-700 text-slate-300 rounded-xl font-medium text-sm hover:bg-slate-600 transition-all flex items-center justify-center gap-2">
                    <WifiOff className="w-4 h-4" /> Disconnect
                  </button>
                )}
              </div>

              {/* Stream Controls */}
              {isConnected && (
                <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 space-y-3">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Stream Controls</p>

                  <div className="flex gap-2">
                    {!isStreaming ? (
                      <button onClick={() => start({ speed })} className="flex-1 py-2.5 bg-gradient-to-r from-emerald-500 to-green-600 text-white rounded-xl font-medium text-sm hover:from-emerald-400 hover:to-green-500 transition-all flex items-center justify-center gap-2">
                        <Play className="w-4 h-4" /> Start
                      </button>
                    ) : (
                      <button onClick={stop} className="flex-1 py-2.5 bg-gradient-to-r from-amber-500 to-orange-600 text-white rounded-xl font-medium text-sm hover:from-amber-400 hover:to-orange-500 transition-all flex items-center justify-center gap-2">
                        <Pause className="w-4 h-4" /> Pause
                      </button>
                    )}
                    <button onClick={reset} className="py-2.5 px-3 bg-slate-700 text-slate-300 rounded-xl hover:bg-slate-600 transition-all" title="Reset">
                      <RotateCcw className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Speed Control */}
                  <div>
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-xs text-slate-400">Speed</span>
                      <span className="text-xs font-mono text-cyan-400">{speed.toFixed(1)}s/row</span>
                    </div>
                    <input
                      type="range"
                      min={0.1}
                      max={3.0}
                      step={0.1}
                      value={speed}
                      onChange={(e) => setSpeed(parseFloat(e.target.value))}
                      className="w-full h-1.5 bg-slate-700 rounded-full appearance-none cursor-pointer accent-cyan-500"
                    />
                    <div className="flex justify-between text-[10px] text-slate-500 mt-0.5">
                      <span>Fast</span><span>Slow</span>
                    </div>
                  </div>

                  {/* Progress */}
                  {stats && (
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span className="text-xs text-slate-400">Progress</span>
                        <span className="text-xs font-mono text-slate-300">{stats.progress}%</span>
                      </div>
                      <div className="h-1.5 bg-slate-700 rounded-full overflow-hidden">
                        <div className="h-full bg-gradient-to-r from-cyan-500 to-blue-500 rounded-full transition-all" style={{ width: `${stats.progress}%` }} />
                      </div>
                    </div>
                  )}
                </div>
              )}

              {/* Quick Stats */}
              {stats && (
                <div className="p-4 bg-slate-800/50 rounded-xl border border-slate-700/50 space-y-2">
                  <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Running Stats</p>
                  <div className="grid grid-cols-2 gap-2 text-center">
                    <div className="p-2 bg-slate-700/50 rounded-lg">
                      <p className="text-lg font-bold text-white">{stats.total_processed}</p>
                      <p className="text-[10px] text-slate-400">Processed</p>
                    </div>
                    <div className="p-2 bg-slate-700/50 rounded-lg">
                      <p className="text-lg font-bold text-red-400">{stats.total_attacks}</p>
                      <p className="text-[10px] text-slate-400">Attacks</p>
                    </div>
                    <div className="p-2 bg-slate-700/50 rounded-lg">
                      <p className="text-lg font-bold text-emerald-400">{stats.total_normal}</p>
                      <p className="text-[10px] text-slate-400">Normal</p>
                    </div>
                    <div className="p-2 bg-slate-700/50 rounded-lg">
                      <p className="text-lg font-bold text-cyan-400">{stats.running_accuracy ?? '—'}%</p>
                      <p className="text-[10px] text-slate-400">Accuracy</p>
                    </div>
                  </div>
                </div>
              )}
            </>
          )}
        </div>

        {/* Bottom */}
        <div className="p-4 border-t border-slate-700/50 space-y-2">
          <button onClick={() => navigate('/dashboard')} className={`w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-white hover:bg-slate-800/50 rounded-xl transition-all ${!sidebarOpen && 'justify-center'}`}>
            <ArrowLeft className="w-5 h-5" />
            {sidebarOpen && <span>Back to Dashboard</span>}
          </button>
          <button onClick={logout} className={`w-full flex items-center gap-3 px-4 py-3 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-xl transition-all ${!sidebarOpen && 'justify-center'}`}>
            <LogOut className="w-5 h-5" />
            {sidebarOpen && <span>Logout</span>}
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 overflow-auto">
        {/* Header */}
        <header className="sticky top-0 z-10 bg-slate-900/80 backdrop-blur-xl border-b border-slate-700/50 px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div>
                <h1 className="text-2xl font-bold text-white flex items-center gap-3">
                  🔴 Live FDI Attack Detection
                  {isStreaming && <span className="flex items-center gap-1.5 px-3 py-1 bg-red-500/20 text-red-400 text-sm font-medium rounded-full"><span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />LIVE</span>}
                </h1>
                <p className="text-sm text-slate-400 mt-1">Real-time DQN-GNN monitoring on SWaT dataset • Row {lastPrediction?.row ?? 0} / {status?.total_rows ?? '449,919'}</p>
              </div>
            </div>
            <div className="flex items-center gap-4">
              <div className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-medium border ${
                isStreaming ? 'bg-red-500/20 text-red-400 border-red-500/30' :
                isConnected ? 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30' :
                'bg-slate-800/50 text-slate-400 border-slate-700'
              }`}>
                <div className={`w-2 h-2 rounded-full ${statusInfo.color} ${statusInfo.pulse ? 'animate-pulse' : ''}`} />
                {statusInfo.text}
              </div>
              <div className="w-10 h-10 rounded-full bg-gradient-to-br from-purple-500 to-pink-500 flex items-center justify-center text-white font-bold">
                {user?.full_name?.charAt(0).toUpperCase()}
              </div>
            </div>
          </div>
        </header>

        <div className="p-8">
          {/* Error Banner */}
          {error && (
            <div className="mb-6 p-4 bg-red-500/20 border border-red-500/30 rounded-xl text-red-300 flex items-center gap-3">
              <AlertTriangle className="w-5 h-5 flex-shrink-0" />
              <span className="text-sm">{error}</span>
            </div>
          )}

          {/* Not Connected State */}
          {!isConnected && !error && (
            <div className="flex flex-col items-center justify-center py-20">
              <div className="w-24 h-24 rounded-full bg-slate-800/50 border-2 border-slate-700 flex items-center justify-center mb-6">
                <Radio className="w-12 h-12 text-slate-500" />
              </div>
              <h2 className="text-2xl font-bold text-white mb-2">Ready for Live Detection</h2>
              <p className="text-slate-400 mb-8 text-center max-w-md">
                Connect to the backend server to begin real-time FDI attack detection on the SWaT dataset using the DQN-GNN model.
              </p>
              <button onClick={connect} className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-blue-600 text-white rounded-xl font-medium hover:from-cyan-400 hover:to-blue-500 transition-all flex items-center gap-3 text-lg shadow-lg shadow-cyan-500/25">
                <Wifi className="w-5 h-5" /> Connect & Start
              </button>
            </div>
          )}

          {/* Connected / Streaming Content */}
          {isConnected && (
            <div className="space-y-6">
              {/* Top Row: Attack Gauge + Current Prediction + Key Metrics */}
              <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                {/* Attack Probability Gauge */}
                <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-2xl p-6 border border-slate-700/50 flex flex-col items-center">
                  <p className="text-sm font-medium text-slate-400 mb-4">Attack Probability</p>
                  <div className="relative w-48 h-24 overflow-hidden">
                    {/* Gauge background */}
                    <div className="absolute bottom-0 left-0 w-48 h-48 rounded-full border-[12px] border-slate-700" style={{ clipPath: 'polygon(0 0, 100% 0, 100% 50%, 0 50%)' }} />
                    {/* Gauge fill */}
                    <div
                      className="absolute bottom-0 left-0 w-48 h-48 rounded-full border-[12px] border-transparent transition-all duration-500"
                      style={{
                        clipPath: 'polygon(0 0, 100% 0, 100% 50%, 0 50%)',
                        borderTopColor: attackProb > 0.7 ? '#ef4444' : attackProb > 0.4 ? '#f59e0b' : '#10b981',
                        borderRightColor: attackProb > 0.5 ? (attackProb > 0.7 ? '#ef4444' : '#f59e0b') : 'transparent',
                        transform: `rotate(${Math.min(attackProb * 180, 180)}deg)`,
                        transformOrigin: 'center center',
                      }}
                    />
                    {/* Needle */}
                    <div className="absolute bottom-0 left-1/2 w-1 h-20 origin-bottom transition-transform duration-500" style={{ transform: `translateX(-50%) rotate(${gaugeRotation}deg)` }}>
                      <div className="w-1 h-16 bg-white rounded-full" />
                    </div>
                    {/* Center dot */}
                    <div className="absolute bottom-0 left-1/2 -translate-x-1/2 translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg" />
                  </div>
                  <p className={`text-4xl font-bold mt-4 ${
                    attackProb > 0.7 ? 'text-red-400' : attackProb > 0.4 ? 'text-amber-400' : 'text-emerald-400'
                  }`}>
                    {(attackProb * 100).toFixed(1)}%
                  </p>
                  <p className="text-xs text-slate-500 mt-1">
                    {attackProb > 0.7 ? '⚠️ HIGH RISK' : attackProb > 0.4 ? '🟡 MODERATE' : '✅ LOW RISK'}
                  </p>
                </div>

                {/* Current Prediction Card */}
                <div className={`rounded-2xl p-6 border transition-all duration-500 ${
                  lastPrediction?.is_attack
                    ? 'bg-gradient-to-br from-red-900/30 to-red-800/20 border-red-500/50'
                    : 'bg-gradient-to-br from-slate-800 to-slate-800/50 border-slate-700/50'
                }`}>
                  <div className="flex items-center justify-between mb-4">
                    <p className="text-sm font-medium text-slate-400">Current Prediction</p>
                    <span className="text-xs font-mono text-slate-500">Row #{lastPrediction?.row ?? '—'}</span>
                  </div>
                  {lastPrediction ? (
                    <>
                      <div className="flex items-center gap-3 mb-4">
                        <div className={`w-16 h-16 rounded-2xl flex items-center justify-center ${
                          lastPrediction.is_attack ? 'bg-red-500/20' : 'bg-emerald-500/20'
                        }`}>
                          {lastPrediction.is_attack ? (
                            <AlertTriangle className="w-8 h-8 text-red-400" />
                          ) : (
                            <Shield className="w-8 h-8 text-emerald-400" />
                          )}
                        </div>
                        <div>
                          <p className={`text-2xl font-bold ${lastPrediction.is_attack ? 'text-red-400' : 'text-emerald-400'}`}>
                            {lastPrediction.is_attack ? 'ATTACK' : 'NORMAL'}
                          </p>
                          <p className="text-sm text-slate-400">
                            {lastPrediction.anomaly_count} anomalous node{lastPrediction.anomaly_count !== 1 ? 's' : ''}
                          </p>
                        </div>
                      </div>
                      {lastPrediction.actual_label !== null && (
                        <div className={`flex items-center gap-2 px-3 py-2 rounded-lg text-sm ${
                          lastPrediction.correct ? 'bg-emerald-500/10 text-emerald-400' : 'bg-red-500/10 text-red-400'
                        }`}>
                          {lastPrediction.correct ? '✓ Correct' : '✗ Incorrect'} • Actual: {lastPrediction.actual_label === 1 ? 'Attack' : 'Normal'}
                        </div>
                      )}
                      {lastPrediction.timestamp && (
                        <p className="text-xs text-slate-500 mt-3 flex items-center gap-1">
                          <Clock className="w-3 h-3" /> {lastPrediction.timestamp}
                        </p>
                      )}
                    </>
                  ) : (
                    <div className="text-center py-6 text-slate-500">
                      <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                      <p className="text-sm">Waiting for data...</p>
                    </div>
                  )}
                </div>

                {/* Key Metrics */}
                <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
                  <p className="text-sm font-medium text-slate-400 mb-4">Key Metrics</p>
                  <div className="space-y-3">
                    <MetricRow icon={<Zap className="w-4 h-4 text-cyan-400" />} label="Recent Attack Rate" value={`${recentAttackRate}%`} valueColor={recentAttackRate > 50 ? 'text-red-400' : recentAttackRate > 20 ? 'text-amber-400' : 'text-emerald-400'} />
                    <MetricRow icon={<TrendingUp className="w-4 h-4 text-emerald-400" />} label="Running Accuracy" value={stats?.running_accuracy !== null && stats?.running_accuracy !== undefined ? `${stats.running_accuracy}%` : '—'} valueColor="text-cyan-400" />
                    <MetricRow icon={<Gauge className="w-4 h-4 text-amber-400" />} label="True Positives" value={String(stats?.tp ?? 0)} valueColor="text-white" />
                    <MetricRow icon={<Gauge className="w-4 h-4 text-blue-400" />} label="True Negatives" value={String(stats?.tn ?? 0)} valueColor="text-white" />
                    <MetricRow icon={<AlertTriangle className="w-4 h-4 text-red-400" />} label="False Positives" value={String(stats?.fp ?? 0)} valueColor="text-red-400" />
                    <MetricRow icon={<AlertTriangle className="w-4 h-4 text-amber-400" />} label="False Negatives" value={String(stats?.fn ?? 0)} valueColor="text-amber-400" />
                  </div>
                </div>
              </div>

              {/* Second Row: Sensor Snapshot + Live Anomalies */}
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                {/* Live Sensor Values */}
                <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Activity className="w-5 h-5 text-cyan-400" /> Live Sensor Readings
                  </h3>
                  {lastPrediction?.sensor_snapshot && Object.keys(lastPrediction.sensor_snapshot).length > 0 ? (
                    <div className="grid grid-cols-2 gap-3">
                      {Object.entries(lastPrediction.sensor_snapshot).map(([sensor, value]) => (
                        <div key={sensor} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                          <span className="text-sm text-slate-300 font-medium">{sensor}</span>
                          <span className="text-sm font-mono text-cyan-400">{value}</span>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-sm text-center py-4">Waiting for sensor data...</p>
                  )}
                </div>

                {/* Recent Anomalies */}
                <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-2xl p-6 border border-slate-700/50">
                  <h3 className="text-lg font-semibold text-white mb-4 flex items-center gap-2">
                    <Bell className="w-5 h-5 text-red-400" /> Live Anomalous Nodes
                  </h3>
                  {recentAnomalies.length > 0 ? (
                    <div className="space-y-2">
                      {recentAnomalies.map(a => (
                        <div key={a.node_id} className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
                          <div className="flex items-center gap-3">
                            <div className={`w-2.5 h-2.5 rounded-full ${
                              a.severity === 'critical' ? 'bg-red-500 animate-pulse' :
                              a.severity === 'high' ? 'bg-orange-500' :
                              a.severity === 'medium' ? 'bg-amber-500' : 'bg-blue-500'
                            }`} />
                            <span className="text-sm font-medium text-white">{a.node_id}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <span className={`px-2 py-0.5 rounded-full text-xs font-semibold ${getSeverityColor(a.severity)}`}>
                              {a.severity}
                            </span>
                            <span className="text-xs text-slate-400">×{a.count}</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-slate-500 text-sm text-center py-4">No anomalies detected yet</p>
                  )}
                </div>
              </div>

              {/* Prediction Feed */}
              <div className="bg-gradient-to-br from-slate-800 to-slate-800/50 rounded-2xl border border-slate-700/50 overflow-hidden">
                <div className="p-6 border-b border-slate-700/50 flex items-center justify-between">
                  <h3 className="text-lg font-semibold text-white flex items-center gap-2">
                    <Radio className="w-5 h-5 text-red-400" /> Live Prediction Feed
                  </h3>
                  <button onClick={() => setShowAllPredictions(!showAllPredictions)} className="text-sm text-cyan-400 hover:text-cyan-300 flex items-center gap-1">
                    {showAllPredictions ? <><ChevronUp className="w-4 h-4" /> Show Less</> : <><ChevronDown className="w-4 h-4" /> Show All ({predictions.length})</>}
                  </button>
                </div>

                {predictions.length === 0 ? (
                  <div className="p-8 text-center text-slate-500">
                    <Activity className="w-8 h-8 mx-auto mb-2 opacity-50" />
                    <p className="text-sm">Predictions will appear here in real-time</p>
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-sm">
                      <thead>
                        <tr className="border-b border-slate-700/50">
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Row</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Timestamp</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Prediction</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Probability</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Actual</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Result</th>
                          <th className="text-left text-xs font-semibold text-slate-400 uppercase tracking-wider px-6 py-3">Anomalies</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-slate-700/30">
                        {(showAllPredictions ? predictions : predictions.slice(0, 25)).map(p => (
                          <PredictionRow key={p.row} prediction={p} />
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            </div>
          )}
        </div>
      </main>
    </div>
  );
};

// ---- Sub-components ----

const MetricRow: React.FC<{ icon: React.ReactNode; label: string; value: string; valueColor: string }> = ({ icon, label, value, valueColor }) => (
  <div className="flex items-center justify-between p-3 bg-slate-700/30 rounded-xl">
    <div className="flex items-center gap-2">
      {icon}
      <span className="text-sm text-slate-300">{label}</span>
    </div>
    <span className={`text-sm font-bold ${valueColor}`}>{value}</span>
  </div>
);

const PredictionRow: React.FC<{ prediction: LivePrediction }> = ({ prediction: p }) => (
  <tr className={`hover:bg-slate-700/20 transition-colors ${p.is_attack ? 'bg-red-500/5' : ''}`}>
    <td className="px-6 py-3 font-mono text-slate-300">#{p.row}</td>
    <td className="px-6 py-3 text-slate-400 text-xs">{p.timestamp || '—'}</td>
    <td className="px-6 py-3">
      <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
        p.is_attack ? 'bg-red-500/20 text-red-400' : 'bg-emerald-500/20 text-emerald-400'
      }`}>
        {p.is_attack ? 'ATTACK' : 'NORMAL'}
      </span>
    </td>
    <td className="px-6 py-3 font-mono text-slate-300">{(p.system_probability * 100).toFixed(1)}%</td>
    <td className="px-6 py-3">
      {p.actual_label !== null ? (
        <span className={`px-2 py-0.5 rounded-full text-xs ${
          p.actual_label === 1 ? 'bg-red-500/10 text-red-400' : 'bg-emerald-500/10 text-emerald-400'
        }`}>
          {p.actual_label === 1 ? 'Attack' : 'Normal'}
        </span>
      ) : <span className="text-slate-600">—</span>}
    </td>
    <td className="px-6 py-3">
      {p.correct === null ? <span className="text-slate-600">—</span> :
        p.correct ? <span className="text-emerald-400 font-semibold">✓</span> : <span className="text-red-400 font-semibold">✗</span>}
    </td>
    <td className="px-6 py-3 text-slate-400">{p.anomaly_count}</td>
  </tr>
);
