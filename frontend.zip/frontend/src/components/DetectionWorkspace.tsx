import React, { useMemo, useRef, useState } from 'react';
import { FileText, Loader2, Wifi, WifiOff, Play, Pause, RotateCcw } from 'lucide-react';
import { modelService } from '../services/api';
import { useLiveDetection } from '../hooks/useLiveDetection';
import { TopologyGraph } from './TopologyGraph';
import type { BatchResult, Topology, TopologyNode } from '../types';

type WorkspaceView = 'upload' | 'topology' | 'live';
type WorkspaceTheme = 'light' | 'dark';

interface DetectionWorkspaceProps {
  view: WorkspaceView;
  theme?: WorkspaceTheme;
  onAfterPredict?: () => void;
}

export const DetectionWorkspace: React.FC<DetectionWorkspaceProps> = ({
  view,
  theme = 'light',
  onAfterPredict,
}) => {
  const [topology, setTopology] = useState<Topology | null>(null);
  const [topologyLoading, setTopologyLoading] = useState(true);

  const [uploadFile, setUploadFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [batchResult, setBatchResult] = useState<BatchResult | null>(null);
  const [uploadError, setUploadError] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [showAllRows, setShowAllRows] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const {
    connectionState,
    lastPrediction,
    status: liveStatus,
    error: liveError,
    speed,
    connect,
    disconnect,
    start,
    stop,
    setSpeed,
    reset,
  } = useLiveDetection();

  const isLiveConnected = connectionState !== 'disconnected' && connectionState !== 'error';
  const isLiveStreaming = connectionState === 'streaming';

  React.useEffect(() => {
    const fetchTopology = async () => {
      try {
        setTopologyLoading(true);
        const topo = await modelService.getTopology();
        setTopology(topo);
      } catch (err) {
        console.error('Error loading topology:', err);
      } finally {
        setTopologyLoading(false);
      }
    };

    fetchTopology();
  }, []);

  const refreshTopology = async () => {
    try {
      setTopologyLoading(true);
      const topo = await modelService.getTopology();
      setTopology(topo);
    } catch (err) {
      console.error('Error refreshing topology:', err);
    } finally {
      setTopologyLoading(false);
    }
  };

  const liveTopology = useMemo<Topology | null>(() => {
    if (!topology) return null;
    if (!lastPrediction) return topology;

    const anomalyMap = new Map(lastPrediction.anomalies.map((a) => [a.node_id, a.confidence]));
    const nodes: TopologyNode[] = topology.nodes.map((n) => {
      const status: TopologyNode['status'] = anomalyMap.has(n.id) ? 'anomaly' : 'normal';
      return {
        ...n,
        status,
        confidence: anomalyMap.get(n.id) ?? 0,
        value: lastPrediction.sensor_snapshot?.[n.id] ?? n.value,
      };
    });

    return { ...topology, nodes };
  }, [topology, lastPrediction]);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') setDragActive(true);
    if (e.type === 'dragleave') setDragActive(false);
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    if (e.dataTransfer.files?.[0]) {
      const file = e.dataTransfer.files[0];
      if (file.name.endsWith('.csv')) {
        setUploadFile(file);
        setUploadError('');
      } else {
        setUploadError('Only CSV files are supported');
      }
    }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files?.[0]) {
      const file = e.target.files[0];
      if (file.name.endsWith('.csv')) {
        setUploadFile(file);
        setUploadError('');
      } else {
        setUploadError('Only CSV files are supported');
      }
    }
  };

  const handleUploadPredict = async () => {
    if (!uploadFile) return;
    setUploading(true);
    setUploadError('');
    setBatchResult(null);
    try {
      const result = await modelService.predictBatch(uploadFile);
      setBatchResult(result);
      onAfterPredict?.();
      await refreshTopology();
    } catch (err: any) {
      setUploadError(err?.response?.data?.detail || 'Error processing the file.');
    } finally {
      setUploading(false);
    }
  };

  const cardClass =
    theme === 'dark'
      ? 'bg-gradient-to-br from-slate-800 to-slate-800/50 border border-slate-700/50 rounded-2xl'
      : 'bg-white border border-gray-100 rounded-xl shadow-sm';

  const textMain = theme === 'dark' ? 'text-white' : 'text-gray-900';
  const textSub = theme === 'dark' ? 'text-slate-400' : 'text-gray-500';

  const renderLiveControls = () => (
    <div className={`${cardClass} p-5`}>
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h3 className={`text-lg font-semibold ${textMain}`}>Live Detection Controls</h3>
          <p className={`text-sm ${textSub}`}>Realtime websocket controls and live inference status.</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          {!isLiveConnected ? (
            <button onClick={connect} className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 flex items-center gap-2">
              <Wifi className="w-4 h-4" /> Connect
            </button>
          ) : (
            <button onClick={disconnect} className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600 flex items-center gap-2">
              <WifiOff className="w-4 h-4" /> Disconnect
            </button>
          )}

          {isLiveConnected && !isLiveStreaming && (
            <button onClick={() => start({ speed })} className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 flex items-center gap-2">
              <Play className="w-4 h-4" /> Start
            </button>
          )}

          {isLiveStreaming && (
            <button onClick={stop} className="px-4 py-2 bg-amber-600 text-white rounded-lg hover:bg-amber-700 flex items-center gap-2">
              <Pause className="w-4 h-4" /> Pause
            </button>
          )}

          <button onClick={reset} disabled={!isLiveConnected} className="px-4 py-2 bg-slate-100 text-slate-800 rounded-lg disabled:opacity-50 flex items-center gap-2">
            <RotateCcw className="w-4 h-4" /> Reset
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-3 mt-4">
        <div className={`${theme === 'dark' ? 'bg-slate-700/40 border-slate-600/50' : 'bg-slate-50 border-slate-200'} p-3 rounded-lg border`}>
          <p className={`text-xs ${textSub}`}>Connection</p>
          <p className={`text-sm font-semibold ${textMain} capitalize`}>{connectionState}</p>
        </div>
        <div className={`${theme === 'dark' ? 'bg-slate-700/40 border-slate-600/50' : 'bg-slate-50 border-slate-200'} p-3 rounded-lg border`}>
          <p className={`text-xs ${textSub}`}>Current Row</p>
          <p className={`text-sm font-semibold ${textMain}`}>{lastPrediction?.row ?? '—'}</p>
        </div>
        <div className={`${theme === 'dark' ? 'bg-slate-700/40 border-slate-600/50' : 'bg-slate-50 border-slate-200'} p-3 rounded-lg border`}>
          <p className={`text-xs ${textSub}`}>Attack Probability</p>
          <p className={`text-sm font-semibold ${textMain}`}>
            {lastPrediction ? `${(lastPrediction.system_probability * 100).toFixed(2)}%` : '—'}
          </p>
        </div>
        <div className={`${theme === 'dark' ? 'bg-slate-700/40 border-slate-600/50' : 'bg-slate-50 border-slate-200'} p-3 rounded-lg border`}>
          <p className={`text-xs ${textSub}`}>Speed</p>
          <div className="flex items-center gap-2">
            <input type="range" min={0.1} max={3} step={0.1} value={speed} onChange={(e) => setSpeed(parseFloat(e.target.value))} className="w-full" />
            <span className={`text-xs font-semibold ${textMain} w-12 text-right`}>{speed.toFixed(1)}s</span>
          </div>
        </div>
      </div>

      {liveStatus && <p className={`mt-3 text-xs ${textSub}`}>{liveStatus.message || `State: ${liveStatus.state}`}</p>}
      {liveError && <p className="mt-2 text-xs text-red-400">{liveError}</p>}
    </div>
  );

  if (view === 'upload') {
    return (
      <div className="space-y-6">
        <div className={`${cardClass} p-6`}>
          <h3 className={`text-lg font-semibold ${textMain} mb-2`}>Upload CSV for Batch Prediction</h3>
          <p className={`text-sm ${textSub} mb-4`}>Upload SWaT CSV data for model evaluation and attack detection.</p>

          <div
            className={`border-2 border-dashed rounded-xl p-10 text-center transition-colors cursor-pointer ${
              dragActive
                ? 'border-cyan-500 bg-cyan-500/10'
                : theme === 'dark'
                  ? 'border-slate-600 hover:border-cyan-400 hover:bg-slate-700/30'
                  : 'border-gray-300 hover:border-cyan-400 hover:bg-gray-50'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
            onClick={() => fileInputRef.current?.click()}
          >
            <input ref={fileInputRef} type="file" accept=".csv" className="hidden" onChange={handleFileSelect} />
            <FileText className={`w-12 h-12 mx-auto mb-3 ${theme === 'dark' ? 'text-slate-400' : 'text-gray-400'}`} />
            <p className={`${theme === 'dark' ? 'text-slate-300' : 'text-gray-700'} font-medium`}>Drag & drop your CSV file here</p>
            <p className={`text-sm mt-1 ${textSub}`}>or click to browse • max 500 rows</p>
          </div>

          {uploadFile && (
            <div className="mt-4 flex items-center justify-between bg-cyan-500/10 rounded-lg px-4 py-3 border border-cyan-500/20">
              <div className="flex items-center gap-3">
                <FileText className="w-5 h-5 text-cyan-400" />
                <div>
                  <p className="text-sm font-medium text-cyan-300">{uploadFile.name}</p>
                  <p className="text-xs text-cyan-400">{(uploadFile.size / 1024).toFixed(1)} KB</p>
                </div>
              </div>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setUploadFile(null);
                    setBatchResult(null);
                    setUploadError('');
                  }}
                  className="px-3 py-2 bg-slate-700 text-slate-300 rounded-lg hover:bg-slate-600"
                >
                  Clear
                </button>
                <button
                  onClick={handleUploadPredict}
                  disabled={uploading}
                  className="px-4 py-2 bg-cyan-600 text-white rounded-lg hover:bg-cyan-700 disabled:opacity-50 flex items-center gap-2"
                >
                  {uploading ? <><Loader2 className="w-4 h-4 animate-spin" /> Running...</> : 'Run Prediction'}
                </button>
              </div>
            </div>
          )}

          {uploadError && <p className="mt-3 text-sm text-red-400">{uploadError}</p>}
        </div>

        {batchResult && (
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className={`${cardClass} p-4`}><p className={textSub}>Rows</p><p className={`text-2xl font-bold ${textMain}`}>{batchResult.total_rows}</p></div>
            <div className={`${cardClass} p-4`}><p className={textSub}>Attacks</p><p className="text-2xl font-bold text-red-400">{batchResult.detected_attacks}</p></div>
            <div className={`${cardClass} p-4`}><p className={textSub}>Normal</p><p className="text-2xl font-bold text-emerald-400">{batchResult.detected_normal}</p></div>
            <div className={`${cardClass} p-4`}><p className={textSub}>Accuracy</p><p className="text-2xl font-bold text-cyan-400">{batchResult.accuracy !== null ? `${batchResult.accuracy}%` : 'N/A'}</p></div>
          </div>
        )}

        {batchResult && (
          <div className={`${cardClass} overflow-hidden`}>
            <div className="p-5 border-b border-slate-700/30 flex items-center justify-between">
              <h3 className={`text-lg font-semibold ${textMain}`}>Prediction Rows</h3>
              <button onClick={() => setShowAllRows(!showAllRows)} className="text-sm text-cyan-400 hover:text-cyan-300">
                {showAllRows ? 'Show Less' : `Show All (${batchResult.rows.length})`}
              </button>
            </div>
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead className="border-b border-slate-700/30">
                  <tr>
                    <th className={`px-4 py-3 text-left ${textSub}`}>Row</th>
                    <th className={`px-4 py-3 text-left ${textSub}`}>Prediction</th>
                    <th className={`px-4 py-3 text-left ${textSub}`}>Probability</th>
                    <th className={`px-4 py-3 text-left ${textSub}`}>Anomalies</th>
                  </tr>
                </thead>
                <tbody>
                  {(showAllRows ? batchResult.rows : batchResult.rows.slice(0, 25)).map((row) => (
                    <tr key={row.row} className="border-b border-slate-700/20">
                      <td className={`px-4 py-2 ${textMain}`}>#{row.row}</td>
                      <td className="px-4 py-2">
                        <span className={`px-2 py-0.5 rounded-full text-xs ${row.is_attack ? 'bg-red-500/20 text-red-300' : 'bg-emerald-500/20 text-emerald-300'}`}>
                          {row.is_attack ? 'ATTACK' : 'NORMAL'}
                        </span>
                      </td>
                      <td className={`px-4 py-2 ${textMain}`}>{(row.system_probability * 100).toFixed(2)}%</td>
                      <td className={`px-4 py-2 ${textMain}`}>{row.anomaly_count}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        )}
      </div>
    );
  }

  if (view === 'topology') {
    const topo = liveTopology || topology;
    const stageGroups: Record<string, TopologyNode[]> = {};
    (topo?.nodes || []).forEach((n) => {
      const stage = n.stage || 'Unknown';
      if (!stageGroups[stage]) stageGroups[stage] = [];
      stageGroups[stage].push(n);
    });

    return (
      <div className="space-y-6">
        {renderLiveControls()}

        <div className={`${cardClass} p-5`}>
          <div className="flex items-center justify-between gap-4">
            <div>
              <h3 className={`text-lg font-semibold ${textMain}`}>Network Topology</h3>
              <p className={`text-sm ${textSub}`}>Live node coloring from streaming predictions.</p>
            </div>
            <button onClick={refreshTopology} className="px-4 py-2 bg-slate-700 text-white rounded-lg hover:bg-slate-600">Refresh Topology</button>
          </div>
        </div>

        {topologyLoading ? (
          <div className={`${cardClass} p-6`}><p className={textSub}>Loading topology...</p></div>
        ) : (
          <TopologyGraph topology={topo} />
        )}

        {topo && (
          <div className={`${cardClass} p-6`}>
            <h4 className={`font-semibold ${textMain} mb-4`}>Stage Sensor View</h4>
            <div className="space-y-4">
              {(topo.stages || Object.keys(stageGroups)).map((stage) => {
                const nodes = stageGroups[stage] || [];
                const color = topo.stage_colors?.[stage] || '#64748b';
                return (
                  <div key={stage} className="rounded-xl border-2 p-4" style={{ borderColor: `${color}40` }}>
                    <div className="flex items-center gap-3 mb-3">
                      <div className="w-3.5 h-3.5 rounded-full" style={{ backgroundColor: color }} />
                      <h5 className={`font-semibold ${textMain}`}>{stage}</h5>
                      <span className={`text-xs px-2 py-0.5 rounded-full ${theme === 'dark' ? 'bg-slate-700 text-slate-300' : 'bg-gray-100 text-gray-600'}`}>{nodes.length} sensors</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {nodes.map((node) => (
                        <div key={node.id} className="flex items-center gap-2 px-3 py-1.5 rounded-lg text-xs font-medium" style={{ backgroundColor: `${color}20`, color }}>
                          <div className={`w-2 h-2 rounded-full ${node.status === 'anomaly' ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`} />
                          {node.label}
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {renderLiveControls()}
      {topologyLoading ? (
        <div className={`${cardClass} p-6`}><p className={textSub}>Loading topology...</p></div>
      ) : (
        <TopologyGraph topology={liveTopology || topology} />
      )}
    </div>
  );
};
