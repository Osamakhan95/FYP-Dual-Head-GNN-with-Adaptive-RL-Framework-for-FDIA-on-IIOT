import React from 'react';
import type { Topology } from '../types';

interface TopologyGraphProps {
  topology: Topology | null;
}

export const TopologyGraph: React.FC<TopologyGraphProps> = ({ topology }) => {
  if (!topology) {
    return (
      <div className="w-full h-full bg-white rounded-xl shadow-sm border border-gray-100 p-6">
        <p className="text-sm text-gray-500">Loading topology...</p>
      </div>
    );
  }

  const STAGE_DEFS: Array<{ key: string; label: string; nodes: string[]; color: string }> = [
    { key: 'P1 - Raw Water', label: 'P1', nodes: ['P102', 'P101', 'MV101', 'LIT101', 'FIT101'], color: '#ef9a9a' },
    { key: 'P2 - Pre-Treatment', label: 'P2', nodes: ['P206', 'P205', 'P204', 'P203', 'P202', 'P201', 'MV201', 'FIT201', 'AIT203', 'AIT202', 'AIT201'], color: '#b3e5fc' },
    { key: 'P3 - Ultrafiltration', label: 'P3', nodes: ['P302', 'P301', 'MV304', 'MV303', 'MV302', 'MV301', 'LIT301', 'FIT301', 'DPIT301'], color: '#a5d6a7' },
    { key: 'P4 - De-Chlorination', label: 'P4', nodes: ['UV401', 'P404', 'P403', 'P402', 'P401', 'LIT401', 'FIT401', 'AIT402', 'AIT401'], color: '#ffe0b2' },
    { key: 'P5 - Reverse Osmosis', label: 'P5', nodes: ['PIT503', 'PIT502', 'PIT501', 'P502', 'P501', 'FIT504', 'FIT503', 'FIT502', 'FIT501', 'AIT504', 'AIT503', 'AIT502', 'AIT501'], color: '#e1bee7' },
    { key: 'P6 - Backwash', label: 'P6', nodes: ['P603', 'P602', 'P601', 'FIT601'], color: '#ffe0b2' },
  ];

  const nodeMap = new Map(topology.nodes.map((n) => [n.id, n]));
  const stageData = STAGE_DEFS.map((stage) => {
    const availableNodes = stage.nodes
      .map((id) => nodeMap.get(id))
      .filter((n): n is NonNullable<typeof n> => Boolean(n));
    return {
      ...stage,
      orderedNodes: availableNodes,
    };
  });

  const W = 1500;
  const H = 900;
  const topY = 135;
  const bottomY = 740;
  const leftMargin = 95;
  const rightMargin = 95;
  const stepX = (W - leftMargin - rightMargin) / (stageData.length - 1);

  const positions: Record<string, { x: number; y: number; stageIndex: number }> = {};

  stageData.forEach((stage, stageIndex) => {
    const x = leftMargin + stageIndex * stepX;
    const count = stage.orderedNodes.length;
    const stepY = count > 1 ? (bottomY - topY) / (count - 1) : 0;

    stage.orderedNodes.forEach((node, idx) => {
      positions[node.id] = {
        x,
        y: topY + idx * stepY,
        stageIndex,
      };
    });
  });

  const intraMachineEdges: Array<{ source: string; target: string }> = [];
  stageData.forEach((stage) => {
    for (let i = 0; i < stage.orderedNodes.length - 1; i += 1) {
      intraMachineEdges.push({
        source: stage.orderedNodes[i].id,
        target: stage.orderedNodes[i + 1].id,
      });
    }
  });

  const interMachineEdges: Array<{ source: string; target: string }> = [];
  for (let i = 0; i < stageData.length - 1; i += 1) {
    const a = stageData[i].orderedNodes;
    const b = stageData[i + 1].orderedNodes;
    a.forEach((na) => {
      b.forEach((nb) => {
        interMachineEdges.push({ source: na.id, target: nb.id });
      });
    });
  }

  return (
    <div className="w-full h-full bg-white rounded-xl shadow-sm border border-gray-100 p-6">
      <div className="mb-4">
        <h3 className="text-lg font-semibold text-gray-900">SWaT Water Treatment System - Graph Structure</h3>
        <p className="text-sm text-gray-600">INTRA-MACHINE: complete local chain | INTER-MACHINE: complete links only between consecutive stages</p>
      </div>

      <div className="w-full overflow-x-auto border border-gray-200 rounded-lg bg-[#f4f4f4]">
        <svg viewBox={`0 0 ${W} ${H}`} className="min-w-[1200px] w-full h-[720px]">
          <defs>
            <filter id="shadow" x="-20%" y="-20%" width="140%" height="140%">
              <feDropShadow dx="0" dy="1" stdDeviation="1.2" floodOpacity="0.25" />
            </filter>
          </defs>

          <text x={W / 2} y={42} textAnchor="middle" fontSize="28" fontWeight="700" fill="#1f2937">
            SWaT Water Treatment System - GRAPH STRUCTURE
          </text>

          <rect x={210} y={58} width={1080} height={26} rx={6} fill="#e5e7eb" stroke="#9ca3af" />
          <text x={750} y={75} textAnchor="middle" fontSize="14" fontWeight="600" fill="#374151">
            INTRA-MACHINE: Complete connections within each machine | INTER-MACHINE: Complete connections only between consecutive machines
          </text>

          {stageData.map((stage, idx) => {
            const x = leftMargin + idx * stepX;
            return (
              <g key={stage.key}>
                <rect x={x - 22} y={95} width={44} height={26} rx={5} fill={stage.color} stroke="#6b7280" />
                <text x={x} y={113} textAnchor="middle" fontSize="18" fontWeight="700" fill="#111827">
                  {stage.label}
                </text>
                <text x={x + 36} y={113} textAnchor="start" fontSize="14" fontWeight="600" fill="#4b5563">
                  {stage.orderedNodes.length} nodes
                </text>
              </g>
            );
          })}

          {interMachineEdges.map((edge, i) => {
            const s = positions[edge.source];
            const t = positions[edge.target];
            if (!s || !t) return null;
            return (
              <line
                key={`inter-${edge.source}-${edge.target}-${i}`}
                x1={s.x}
                y1={s.y}
                x2={t.x}
                y2={t.y}
                stroke="#2f3bff"
                strokeWidth={2}
                opacity={0.62}
              />
            );
          })}

          {intraMachineEdges.map((edge, i) => {
            const s = positions[edge.source];
            const t = positions[edge.target];
            if (!s || !t) return null;
            return (
              <line
                key={`intra-${edge.source}-${edge.target}-${i}`}
                x1={s.x}
                y1={s.y}
                x2={t.x}
                y2={t.y}
                stroke="#ff3b30"
                strokeWidth={3}
                opacity={0.9}
              />
            );
          })}

          {stageData.map((stage) =>
            stage.orderedNodes.map((node) => {
              const p = positions[node.id];
              if (!p) return null;
              const isAnomaly = node.status === 'anomaly';

              return (
                <g key={node.id} filter="url(#shadow)">
                  <circle
                    cx={p.x}
                    cy={p.y}
                    r={15}
                    fill={stage.color}
                    stroke={isAnomaly ? '#dc2626' : '#64748b'}
                    strokeWidth={isAnomaly ? 3 : 1.8}
                  />
                  <text
                    x={p.x}
                    y={p.y + 4.5}
                    textAnchor="middle"
                    fontSize={9.2}
                    fontWeight={700}
                    fill="#111827"
                  >
                    {node.label}
                  </text>
                  <title>{`${node.label} | ${node.status.toUpperCase()} | confidence ${(node.confidence ?? 0).toFixed(3)}`}</title>
                </g>
              );
            }),
          )}

          <text x={750} y={782} textAnchor="middle" fontSize="25" fontWeight="700" fill="#16a34a">
            WATER FLOW DIRECTION: P1 → P2 → P3 → P4 → P5 → P6
          </text>

          <rect x={485} y={798} width={530} height={84} rx={4} fill="#efefef" stroke="#bdbdbd" />

          <line x1={520} y1={824} x2={555} y2={824} stroke="#ff3b30" strokeWidth={3} />
          <text x={568} y={828} fontSize={14} fontWeight={600} fill="#1f2937">
            INTRA-MACHINE: All nodes connected within same machine
          </text>

          <line x1={520} y1={848} x2={555} y2={848} stroke="#2f3bff" strokeWidth={2.5} />
          <text x={568} y={852} fontSize={14} fontWeight={600} fill="#1f2937">
            INTER-MACHINE: All nodes connected between consecutive machines
          </text>

          <circle cx={537} cy={871} r={4} fill="#6b7280" />
          <text x={568} y={875} fontSize={14} fontWeight={600} fill="#1f2937">
            NO CONNECTION: Between non-adjacent machines
          </text>
        </svg>
      </div>
    </div>
  );
};
