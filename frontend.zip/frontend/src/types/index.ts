export interface User {
  id: number;
  name?: string;
  full_name: string;
  employee_id?: string;
  email: string;
  role: 'admin' | 'user';
  status: 'pending' | 'approved' | 'declined';
  is_active?: boolean;
  email_verified?: boolean;
  created_at: string;
}

export interface LoginCredentials {
  email: string;
  password: string;
}

export interface SignupData {
  name: string;
  employee_id: string;
  email: string;
  password: string;
  confirm_password: string;
  recaptcha_token?: string;
}

export interface AuthResponse {
  access_token: string;
  token_type: string;
  user: User;
}

// ---- Anomaly ----
export interface Anomaly {
  id: number;
  node_id: string;
  confidence: number;
  detected_at: string;
  is_resolved: boolean;
  severity: 'low' | 'medium' | 'high' | 'critical';
}

// ---- Topology ----
export interface TopologyNode {
  id: string;
  label: string;
  status: 'normal' | 'anomaly';
  stage?: string;
  color?: string;
  confidence?: number;
  value?: number;
  x?: number;
  y?: number;
}

export interface TopologyEdge {
  source: string;
  target: string;
  type?: string;
}

export interface Topology {
  nodes: TopologyNode[];
  edges: TopologyEdge[];
  stages?: string[];
  stage_colors?: Record<string, string>;
}

// ---- Prediction ----
export interface PredictionResult {
  anomalies: {
    node_id: string;
    confidence: number;
    severity: string;
    attack_type: string;
    description: string;
  }[];
  topology: Topology;
  system_probability: number;
  is_attack: boolean;
  timestamp: string;
}

export interface BatchRow {
  row: number;
  is_attack: boolean;
  system_probability: number;
  anomaly_count: number;
  actual_label: number | null;
}

export interface BatchResult {
  filename: string;
  total_rows: number;
  detected_attacks: number;
  detected_normal: number;
  accuracy: number | null;
  confusion_matrix: {
    true_positives: number;
    true_negatives: number;
    false_positives: number;
    false_negatives: number;
  } | null;
  severity_counts: Record<string, number>;
  top_attacked_nodes: { node: string; count: number }[];
  rows: BatchRow[];
  timestamp: string;
}

// ---- Analytics ----
export interface Analytics {
  total_users: number;
  active_users?: number;
  pending_users: number;
  total_anomalies: number;
  anomalies_today: number;
  unresolved_anomalies?: number;
  severity_counts?: Record<string, number>;
  attack_types?: Record<string, number>;
  top_attacked_nodes?: { node: string; count: number }[];
  model_accuracy?: number;
  system_health?: string;
}

// ---- Model Stats ----
export interface ModelStats {
  total_anomalies: number;
  unresolved_anomalies: number;
  resolved_anomalies: number;
  anomalies_today: number;
  severity_counts: Record<string, number>;
  top_attacked_nodes: { node: string; count: number }[];
  model_params: number;
  model_accuracy: number;
}
