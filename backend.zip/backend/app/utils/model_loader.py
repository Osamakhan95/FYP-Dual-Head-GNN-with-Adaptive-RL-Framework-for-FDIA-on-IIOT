import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Dict, List
import os
import zipfile
import tempfile
import numpy as np

try:
    from torch_geometric.nn import GCNConv
except ModuleNotFoundError:
    class GCNConv(nn.Module):
        def __init__(self, in_channels: int, out_channels: int):
            super().__init__()
            self.linear = nn.Linear(in_channels, out_channels)

        def forward(self, x, edge_index=None):
            return self.linear(x)

class SWATFDAIModel(nn.Module):
    """
    SWAT False Data Injection Attack Detection Model
    
    Architecture:
    - Feature Extraction: MLP (1 → 128 → 64 → 32)
    - Graph Neural Network: 2x GCN layers (32 → 32)
    - Temporal Module: Bidirectional LSTM (32 → 64)
    - Feature Fusion: Concatenate GCN + LSTM outputs, then linear (96 → 64)
    - Attention: Multi-Head Self-Attention (64 → 64)
    - Classification: MLP (64 → 32 → 16 → 8 → 1)
    """
    
    def __init__(self, input_dim: int = 1, hidden_dim: int = 32, lstm_hidden: int = 32, num_heads: int = 4):
        super(SWATFDAIModel, self).__init__()
        
        # Feature extraction layers (MLP)
        self.linear1 = nn.Linear(input_dim, 128)
        self.linear2 = nn.Linear(128, 64)
        self.linear3 = nn.Linear(64, hidden_dim)
        
        # Graph Convolutional Network layers
        self.gcn1 = GCNConv(hidden_dim, hidden_dim)
        self.gcn2 = GCNConv(hidden_dim, hidden_dim)
        
        # Bidirectional LSTM for temporal patterns
        self.bilstm = nn.LSTM(
            input_size=hidden_dim,
            hidden_size=lstm_hidden,
            batch_first=True,
            bidirectional=True
        )
        
        # Fusion layer (GCN output 32 + BiLSTM output 64 = 96)
        self.fuse_linear = nn.Linear(hidden_dim + lstm_hidden * 2, 64)
        
        # Multi-Head Self-Attention
        self.attention = nn.MultiheadAttention(embed_dim=64, num_heads=num_heads, batch_first=True)
        
        # Classification head
        self.fc_fuse1 = nn.Linear(64, 32)
        self.fc_fuse2 = nn.Linear(32, 16)
        self.fc_out = nn.Linear(16, 8)
        self.fc_final = nn.Linear(8, 1)
    
    def forward(self, x, edge_index, batch=None):
        """
        Forward pass
        
        Args:
            x: Node features [num_nodes, input_dim]
            edge_index: Graph connectivity [2, num_edges]
            batch: Batch indices for graph batching (optional)
        
        Returns:
            Attack probability [batch_size, 1] or [num_nodes, 1]
        """
        # Feature extraction
        x = F.relu(self.linear1(x))
        x = F.relu(self.linear2(x))
        x = F.relu(self.linear3(x))  # [num_nodes, 32]
        
        # GCN layers
        gcn_out = F.relu(self.gcn1(x, edge_index))
        gcn_out = F.relu(self.gcn2(gcn_out, edge_index))  # [num_nodes, 32]
        
        # LSTM (treat nodes as sequence)
        lstm_in = x.unsqueeze(0)  # [1, num_nodes, 32]
        lstm_out, _ = self.bilstm(lstm_in)  # [1, num_nodes, 64]
        lstm_out = lstm_out.squeeze(0)  # [num_nodes, 64]
        
        # Concatenate GCN and LSTM outputs
        fused = torch.cat([gcn_out, lstm_out], dim=-1)  # [num_nodes, 96]
        fused = F.relu(self.fuse_linear(fused))  # [num_nodes, 64]
        
        # Self-Attention
        attn_in = fused.unsqueeze(0)  # [1, num_nodes, 64]
        attn_out, _ = self.attention(attn_in, attn_in, attn_in)
        attn_out = attn_out.squeeze(0)  # [num_nodes, 64]
        
        # Classification head
        out = F.relu(self.fc_fuse1(attn_out))
        out = F.relu(self.fc_fuse2(out))
        out = F.relu(self.fc_out(out))
        out = torch.sigmoid(self.fc_final(out))  # [num_nodes, 1]
        
        return out


class ModelInference:
    """Handle model loading and inference for SWAT FDAI detection"""
    
    # SWaT dataset sensor ranges for min-max normalization
    # These ranges are computed from the SWaT test dataset
    SENSOR_RANGES = {
        'FIT101': (0.0, 2.7601), 'LIT101': (189.8263, 925.0323),
        'MV101': (0.0, 2.0), 'P101': (1.0, 2.0), 'P102': (1.0, 2.0),
        'AIT201': (168.0338, 267.7198), 'AIT202': (6.0, 8.7332),
        'AIT203': (285.3371, 384.4655), 'FIT201': (0.0, 2.8269), 'MV201': (0.0, 2.0),
        'P201': (1.0, 2.0), 'P202': (1.0, 2.0), 'P203': (1.0, 2.0),
        'P204': (1.0, 2.0), 'P205': (1.0, 2.0), 'P206': (1.0, 2.0),
        'DPIT301': (0.0, 53.4817), 'FIT301': (0.0, 2.4506), 'LIT301': (0.0, 1200.0),
        'MV301': (0.0, 2.0), 'MV302': (0.0, 2.0), 'MV303': (0.0, 2.0),
        'MV304': (0.0, 2.0), 'P301': (1.0, 2.0), 'P302': (1.0, 2.0),
        'AIT401': (50.0, 260.961), 'AIT402': (50.0, 310.8338),
        'FIT401': (0.0, 2.3135), 'LIT401': (0.0, 1200.0),
        'P401': (1.0, 2.0), 'P402': (1.0, 2.0), 'P403': (1.0, 2.0),
        'P404': (1.0, 2.0), 'UV401': (1.0, 2.0),
        'AIT501': (0.0, 18.4261), 'AIT502': (0.0, 292.1508),
        'AIT503': (0.0, 473.1505), 'AIT504': (0.0, 22.2945),
        'FIT501': (0.0, 2.4389), 'FIT502': (0.0, 2.2476),
        'FIT503': (0.0, 1.3587), 'FIT504': (0.0, 0.5662),
        'P501': (1.0, 2.0), 'P502': (1.0, 2.0),
        'PIT501': (0.0, 442.2824), 'PIT502': (0.0, 3.0),
        'PIT503': (0.0, 360.6988), 'FIT601': (0.0, 1.5282),
        'P601': (1.0, 2.0), 'P602': (1.0, 2.0), 'P603': (1.0, 2.0),
    }
    
    # SWaT sensor column order (as in the dataset)
    SENSOR_ORDER = [
        'FIT101', 'LIT101', 'MV101', 'P101', 'P102',
        'AIT201', 'AIT202', 'AIT203', 'FIT201', 'MV201',
        'P201', 'P202', 'P203', 'P204', 'P205', 'P206',
        'DPIT301', 'FIT301', 'LIT301', 'MV301', 'MV302', 'MV303', 'MV304', 'P301', 'P302',
        'AIT401', 'AIT402', 'FIT401', 'LIT401', 'P401', 'P402', 'P403', 'P404', 'UV401',
        'AIT501', 'AIT502', 'AIT503', 'AIT504', 'FIT501', 'FIT502', 'FIT503', 'FIT504',
        'P501', 'P502', 'PIT501', 'PIT502', 'PIT503', 'FIT601', 'P601', 'P602', 'P603',
    ]
    
    def __init__(self, model_path: str = None):
        self.device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
        self.model = None
        
        if model_path is None:
            # Default path to the model
            model_path = os.path.join(os.path.dirname(__file__), "../../..", "swat_fdai_model_final.pth")
        
        self.load_model(model_path)
    
    def load_model(self, model_path: str):
        """Load the trained PyTorch model"""
        try:
            # Initialize model architecture
            self.model = SWATFDAIModel()
            
            # Check if path exists
            if not os.path.exists(model_path):
                print(f"Warning: Model file not found at {model_path}")
                print("Using untrained model for demo purposes")
                self.model.to(self.device)
                self.model.eval()
                return
            
            # Handle directory-based PyTorch save format
            if os.path.isdir(model_path):
                checkpoint = self._load_from_directory(model_path)
            else:
                checkpoint = torch.load(model_path, map_location=self.device, weights_only=False)
            
            # Load state dict
            if isinstance(checkpoint, dict) and 'state_dict' in checkpoint:
                self.model.load_state_dict(checkpoint['state_dict'])
            else:
                self.model.load_state_dict(checkpoint)
            
            self.model.to(self.device)
            self.model.eval()
            print(f"Model loaded successfully from {model_path}")
            print(f"Total parameters: {sum(p.numel() for p in self.model.parameters()):,}")
            
        except Exception as e:
            print(f"Error loading model: {e}")
            print("Using untrained model for demo purposes")
            self.model = SWATFDAIModel()
            self.model.to(self.device)
            self.model.eval()
    
    def _load_from_directory(self, model_dir: str) -> dict:
        """Load model from PyTorch's directory-based save format"""
        # Find the inner directory
        inner_dir = None
        for item in os.listdir(model_dir):
            item_path = os.path.join(model_dir, item)
            if os.path.isdir(item_path) and os.path.exists(os.path.join(item_path, 'data.pkl')):
                inner_dir = item_path
                break
        
        if inner_dir is None:
            inner_dir = model_dir
        
        # Create temporary zip file
        with tempfile.NamedTemporaryFile(suffix='.zip', delete=False) as tmp_file:
            tmp_path = tmp_file.name
        
        try:
            archive_name = os.path.basename(inner_dir)
            with zipfile.ZipFile(tmp_path, 'w') as zipf:
                for root, dirs, files in os.walk(inner_dir):
                    for file in files:
                        filepath = os.path.join(root, file)
                        rel_path = os.path.relpath(filepath, inner_dir)
                        arcname = f'{archive_name}/{rel_path}'
                        zipf.write(filepath, arcname)
            
            checkpoint = torch.load(tmp_path, map_location=self.device, weights_only=False)
            return checkpoint
        finally:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
    
    def predict(self, sensor_data: Dict) -> Dict:
        """
        Make predictions on sensor data
        
        Args:
            sensor_data: Dictionary containing sensor readings
                Supports SWaT names: {"FIT101": 1.23, "LIT101": 500.0, ...}
                Or generic names: {"sensor_0": 0.5, "sensor_1": 0.3, ...}
            
        Returns:
            Dictionary with anomaly predictions and topology
        """
        try:
            # Preprocess data (includes normalization)
            x, edge_index, sensor_names = self._preprocess_data(sensor_data)
            
            with torch.no_grad():
                # Get predictions for each node
                predictions = self.model(x, edge_index)
            
            # Process predictions
            anomalies = self._process_predictions(predictions, sensor_names, sensor_data)
            topology = self._generate_topology(sensor_names, sensor_data, predictions)
            
            # Use a Sigmoid to map raw model signals definitively to a 0.0 - 1.0 attack probability
            mean_prob = float(np.mean(predictions.cpu().numpy().flatten()))
            z = (0.13 - mean_prob) * 30
            import math
            system_probability = 1 / (1 + math.exp(-z))
            
            return {
                "anomalies": anomalies,
                "topology": topology,
                "system_probability": system_probability,
                "is_attack": system_probability >= 0.5
            }
        except Exception as e:
            print(f"Prediction error: {e}")
            import traceback
            traceback.print_exc()
            return {
                "anomalies": [],
                "topology": {"nodes": [], "edges": []},
                "system_probability": 0.0,
                "is_attack": False
            }
    
    def _preprocess_data(self, sensor_data: Dict):
        """
        Preprocess sensor data for model input with min-max normalization.
        
        Accepts sensor data with SWaT sensor names (FIT101, LIT101, etc.)
        or generic names (sensor_0, sensor_1, etc.).
        
        Returns:
            x: Normalized node features tensor [num_nodes, 1]
            edge_index: Graph connectivity [2, num_edges]
            sensor_names: Ordered list of sensor names used
        """
        sensor_values = []
        used_sensor_names = []
        
        # Check if data uses SWaT sensor names or generic names
        has_swat_names = any(k in self.SENSOR_RANGES for k in sensor_data.keys())
        
        if has_swat_names:
            # Use the canonical SWaT sensor order
            for name in self.SENSOR_ORDER:
                if name in sensor_data:
                    raw_value = float(sensor_data[name])
                    # Apply min-max normalization
                    min_val, max_val = self.SENSOR_RANGES[name]
                    if max_val > min_val:
                        normalized = (raw_value - min_val) / (max_val - min_val)
                        normalized = max(0.0, min(1.0, normalized))  # Clamp to [0, 1]
                    else:
                        normalized = 0.5  # Default for constant-range sensors
                    sensor_values.append(normalized)
                    used_sensor_names.append(name)
        else:
            # Generic sensor names (sensor_0, sensor_1, ...) — assume pre-normalized
            generic_names = sorted(
                [k for k in sensor_data.keys() if k.startswith('sensor') or k.startswith('node')],
                key=lambda n: int(''.join(filter(str.isdigit, n)) or 0)
            )
            if not generic_names:
                generic_names = list(sensor_data.keys())
            
            for name in generic_names:
                value = sensor_data.get(name, 0.0)
                if isinstance(value, (int, float)):
                    sensor_values.append(float(value))
                    # Map generic name to SWaT name if index matches
                    idx = len(used_sensor_names)
                    if idx < len(self.SENSOR_ORDER):
                        used_sensor_names.append(self.SENSOR_ORDER[idx])
                    else:
                        used_sensor_names.append(name)
        
        num_nodes = len(sensor_values)
        if num_nodes == 0:
            raise ValueError("No valid sensor data provided")
        
        # Create node features [num_nodes, 1]
        x = torch.tensor(sensor_values, dtype=torch.float32).unsqueeze(1).to(self.device)
        
        # Create edge index — chain topology with cross-connections (matches training)
        edges = []
        for i in range(num_nodes - 1):
            edges.append([i, i + 1])
            edges.append([i + 1, i])  # Bidirectional
        
        # Cross-connections between process stages
        if num_nodes > 5:
            edges.append([0, num_nodes // 2])
            edges.append([num_nodes // 2, 0])
            edges.append([num_nodes // 2, num_nodes - 1])
            edges.append([num_nodes - 1, num_nodes // 2])
        
        edge_index = torch.tensor(edges, dtype=torch.long).t().contiguous().to(self.device)
        
        return x, edge_index, used_sensor_names
    
    def _process_predictions(self, predictions: torch.Tensor, sensor_names: List[str], sensor_data: Dict) -> List[Dict]:
        """Process model predictions into anomaly list"""
        anomalies = []
        predictions_np = predictions.cpu().numpy().flatten()
        
        # Calculate a network-level normalized attack probability
        # The raw output models a "health state" (higher probability for normal operation).
        # We invert it into an attack scope metric using a sigmoid transformation.
        mean_prob = float(np.mean(predictions_np))
        z = (0.13 - mean_prob) * 30  # Standard scale tuning parameters
        import math
        overall_attack_prob = 1 / (1 + math.exp(-z))
        
        # Dynamically flag nodes only if overall risk is high enough and they deviate
        for i, prob in enumerate(predictions_np):
            if i >= len(sensor_names):
                break
            
            node_id = sensor_names[i]
            
            # Since standard output is lower for attacks, a very low prob implies a failure locus
            node_attack_conf = 1.0 - float(prob)
            
            # Use dynamic thresholding based on system logic
            if overall_attack_prob > 0.5 and node_attack_conf > 0.8:
                if node_attack_conf > 0.95:
                    severity = "critical"
                elif node_attack_conf > 0.90:
                    severity = "high"
                elif node_attack_conf > 0.85:
                    severity = "medium"
                else:
                    severity = "low"
                
                anomalies.append({
                    "node_id": node_id,
                    "confidence": float(node_attack_conf),
                    "severity": severity,
                    "attack_type": "FDI Attack",
                    "description": f"Potential FDI attack detected on {node_id}"
                })
        
        return anomalies
    
    def _generate_topology(self, sensor_names: List[str], sensor_data: Dict, predictions: torch.Tensor) -> Dict:
        """Generate network topology with anomaly status"""
        predictions_np = predictions.cpu().numpy().flatten()
        
        nodes = []
        for i, name in enumerate(sensor_names):
            prob = predictions_np[i] if i < len(predictions_np) else 0.0
            
            status = "anomaly" if prob > 0.5 else "normal"
            
            # Determine SWaT process stage for layout grouping
            stage = self._get_process_stage(name)
            
            nodes.append({
                "id": name,
                "label": name,
                "status": status,
                "confidence": float(prob),
                "value": sensor_data.get(name, 0.0),
                "stage": stage,
                "x": (i % 8) * 120 + 50,
                "y": (i // 8) * 120 + 50
            })
        
        # Create edges (chain topology with cross-connections)
        edges = []
        num_nodes = len(sensor_names)
        for i in range(num_nodes - 1):
            edges.append({
                "source": sensor_names[i],
                "target": sensor_names[i + 1],
                "type": "data_flow"
            })
        
        # Add cross-connections between SWaT process stages
        if num_nodes > 5:
            edges.append({
                "source": sensor_names[0],
                "target": sensor_names[num_nodes // 2],
                "type": "control"
            })
            edges.append({
                "source": sensor_names[num_nodes // 2],
                "target": sensor_names[-1],
                "type": "control"
            })
        
        return {"nodes": nodes, "edges": edges}
    
    @staticmethod
    def _get_process_stage(sensor_name: str) -> str:
        """Determine SWaT process stage from sensor name"""
        if any(sensor_name.startswith(p) for p in ['FIT1', 'LIT1', 'MV1', 'P1']):
            return "P1 - Raw Water"
        elif any(sensor_name.startswith(p) for p in ['AIT2', 'FIT2', 'MV2', 'P2']):
            return "P2 - Pre-Treatment"
        elif any(sensor_name.startswith(p) for p in ['DPIT3', 'FIT3', 'LIT3', 'MV3', 'P3']):
            return "P3 - Ultrafiltration"
        elif any(sensor_name.startswith(p) for p in ['AIT4', 'FIT4', 'LIT4', 'P4', 'UV4']):
            return "P4 - De-Chlorination"
        elif any(sensor_name.startswith(p) for p in ['AIT5', 'FIT5', 'P5', 'PIT5']):
            return "P5 - RO"
        elif any(sensor_name.startswith(p) for p in ['FIT6', 'P6']):
            return "P6 - Backwash"
        return "Unknown"


# Global model instance
model_inference = ModelInference()
