from fastapi import APIRouter, Depends, HTTPException, UploadFile, File
from sqlalchemy.orm import Session
from sqlalchemy import func as sql_func
from app.database import get_db
from app.schemas import PredictionRequest, AnomalyResponse
from app.utils.model_loader import model_inference
from app.models import Anomaly
from app.models.user import User, UserRole
from app.utils.auth import decode_access_token
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from datetime import datetime, timezone, timedelta
from typing import List
import csv

router = APIRouter(prefix="/model", tags=["Model"])
security = HTTPBearer()


def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: Session = Depends(get_db)
):
    """Verify authenticated user from JWT token"""
    token = credentials.credentials
    payload = decode_access_token(token)
    if not payload:
        raise HTTPException(status_code=401, detail="Invalid authentication credentials")
    email = payload.get("sub")
    user = db.query(User).filter(User.email == email).first()
    if not user:
        raise HTTPException(status_code=404, detail="User not found")
    return user


@router.post("/predict")
async def predict_anomalies(
    request: PredictionRequest,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Run prediction on a single row of sensor data."""
    try:
        result = model_inference.predict(request.sensor_data)
        for anomaly_data in result.get("anomalies", []):
            db.add(Anomaly(
                node_id=anomaly_data["node_id"],
                confidence=anomaly_data["confidence"],
                severity=anomaly_data.get("severity", "medium")
            ))
        db.commit()
        return {
            "anomalies": result.get("anomalies", []),
            "topology": result.get("topology", {"nodes": [], "edges": []}),
            "system_probability": result.get("system_probability", 0.0),
            "is_attack": result.get("is_attack", False),
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@router.post("/predict-batch")
async def predict_batch(
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Upload a CSV file and run predictions on all rows (max 500)."""
    if not file.filename or not file.filename.endswith('.csv'):
        raise HTTPException(status_code=400, detail="Only CSV files are supported")
    try:
        contents = await file.read()
        text = contents.decode('utf-8')
        lines = text.strip().split('\n')
        reader = csv.reader(lines)
        all_rows = list(reader)
        if len(all_rows) < 2:
            raise HTTPException(status_code=400, detail="CSV file is empty or has no data rows")

        header = [col.strip() for col in all_rows[0]]
        data_start = 1
        # SWaT dataset has 2 header rows
        if len(all_rows) > 2:
            second_row = [col.strip() for col in all_rows[1]]
            known = {'FIT101', 'LIT101', 'MV101', 'P101', 'AIT201', 'Timestamp'}
            if any(s in second_row for s in known):
                header = second_row
                data_start = 2

        excluded = {'Timestamp', 'Normal/Attack', '', 'label', 'Label'}
        sensor_indices, sensor_names = [], []
        for i, col in enumerate(header):
            if col not in excluded:
                sensor_indices.append(i)
                sensor_names.append(col)

        label_idx = None
        for i, col in enumerate(header):
            if col in ('Normal/Attack', 'label', 'Label'):
                label_idx = i
                break

        max_rows = min(len(all_rows) - data_start, 500)
        results = []
        tp = tn = fp = fn = 0
        severity_counts = {"critical": 0, "high": 0, "medium": 0, "low": 0}
        all_anomaly_nodes = {}

        for row_idx in range(data_start, data_start + max_rows):
            row = all_rows[row_idx]
            sensor_data = {}
            for si, sn in zip(sensor_indices, sensor_names):
                if si < len(row):
                    try:
                        sensor_data[sn] = float(row[si].strip())
                    except (ValueError, IndexError):
                        sensor_data[sn] = 0.0

            actual_label = None
            if label_idx is not None and label_idx < len(row):
                try:
                    actual_label = int(float(row[label_idx].strip()))
                except (ValueError, IndexError):
                    pass

            result = model_inference.predict(sensor_data)
            is_attack = result.get("is_attack", False)
            system_prob = result.get("system_probability", 0.0)

            if actual_label is not None:
                if actual_label == 1:
                    if is_attack: tp += 1
                    else: fn += 1
                else:
                    if is_attack: fp += 1
                    else: tn += 1

            for a in result.get("anomalies", []):
                sev = a.get("severity", "low")
                severity_counts[sev] = severity_counts.get(sev, 0) + 1
                node = a.get("node_id", "unknown")
                all_anomaly_nodes[node] = all_anomaly_nodes.get(node, 0) + 1

            for anomaly_data in result.get("anomalies", []):
                db.add(Anomaly(
                    node_id=anomaly_data["node_id"],
                    confidence=anomaly_data["confidence"],
                    severity=anomaly_data.get("severity", "medium")
                ))

            results.append({
                "row": row_idx - data_start + 1,
                "is_attack": is_attack,
                "system_probability": round(system_prob, 4),
                "anomaly_count": len(result.get("anomalies", [])),
                "actual_label": actual_label
            })

        db.commit()

        total_rows = len(results)
        detected_attacks = sum(1 for r in results if r["is_attack"])
        total_eval = tp + tn + fp + fn
        accuracy = round((tp + tn) / total_eval * 100, 1) if total_eval > 0 else None
        top_attacked = sorted(all_anomaly_nodes.items(), key=lambda x: x[1], reverse=True)[:10]

        return {
            "filename": file.filename,
            "total_rows": total_rows,
            "detected_attacks": detected_attacks,
            "detected_normal": total_rows - detected_attacks,
            "accuracy": accuracy,
            "confusion_matrix": {"true_positives": tp, "true_negatives": tn, "false_positives": fp, "false_negatives": fn} if total_eval > 0 else None,
            "severity_counts": severity_counts,
            "top_attacked_nodes": [{"node": n, "count": c} for n, c in top_attacked],
            "rows": results,
            "timestamp": datetime.now(timezone.utc).isoformat()
        }
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Error processing CSV: {str(e)}")


@router.get("/anomalies", response_model=List[AnomalyResponse])
async def get_anomalies(
    limit: int = 50,
    resolved: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get recent anomalies from the database"""
    query = db.query(Anomaly)
    if not resolved:
        query = query.filter(Anomaly.is_resolved == False)
    return query.order_by(Anomaly.detected_at.desc()).limit(limit).all()


@router.post("/anomalies/{anomaly_id}/resolve")
async def resolve_anomaly(
    anomaly_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Mark an anomaly as resolved"""
    anomaly = db.query(Anomaly).filter(Anomaly.id == anomaly_id).first()
    if not anomaly:
        raise HTTPException(status_code=404, detail="Anomaly not found")
    anomaly.is_resolved = True
    db.commit()
    return {"message": "Anomaly resolved", "anomaly_id": anomaly_id}


@router.get("/topology")
async def get_current_topology(current_user: User = Depends(get_current_user)):
    """Get the SWaT IIoT network topology with 51 sensor nodes grouped by process stage"""
    stages = {
        "P1 - Raw Water": ["FIT101", "LIT101", "MV101", "P101", "P102"],
        "P2 - Pre-Treatment": ["AIT201", "AIT202", "AIT203", "FIT201", "MV201", "P201", "P202", "P203", "P204", "P205", "P206"],
        "P3 - Ultrafiltration": ["DPIT301", "FIT301", "LIT301", "MV301", "MV302", "MV303", "MV304", "P301", "P302"],
        "P4 - De-Chlorination": ["AIT401", "AIT402", "FIT401", "LIT401", "P401", "P402", "P403", "P404", "UV401"],
        "P5 - Reverse Osmosis": ["AIT501", "AIT502", "AIT503", "AIT504", "FIT501", "FIT502", "FIT503", "FIT504", "P501", "P502", "PIT501", "PIT502", "PIT503"],
        "P6 - Backwash": ["FIT601", "P601", "P602", "P603"],
    }
    stage_colors = {
        "P1 - Raw Water": "#3b82f6", "P2 - Pre-Treatment": "#8b5cf6",
        "P3 - Ultrafiltration": "#06b6d4", "P4 - De-Chlorination": "#f59e0b",
        "P5 - Reverse Osmosis": "#ef4444", "P6 - Backwash": "#10b981",
    }
    nodes, edges = [], []
    y_offset = 0
    prev_last = None
    for stage_name, sensors in stages.items():
        for i, sensor in enumerate(sensors):
            nodes.append({
                "id": sensor, "label": sensor, "status": "normal",
                "stage": stage_name, "color": stage_colors.get(stage_name, "#64748b"),
                "x": (i % 6) * 130 + 80, "y": y_offset + (i // 6) * 100 + 60
            })
            if i > 0:
                edges.append({"source": sensors[i - 1], "target": sensor, "type": "data_flow"})
        if prev_last and sensors:
            edges.append({"source": prev_last, "target": sensors[0], "type": "control"})
        prev_last = sensors[-1] if sensors else prev_last
        y_offset += ((len(sensors) - 1) // 6 + 1) * 100 + 40
    return {"nodes": nodes, "edges": edges, "stages": list(stages.keys()), "stage_colors": stage_colors}


@router.get("/stats")
async def get_model_stats(
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get overall model/anomaly statistics"""
    total_anomalies = db.query(Anomaly).count()
    unresolved = db.query(Anomaly).filter(Anomaly.is_resolved == False).count()
    resolved = db.query(Anomaly).filter(Anomaly.is_resolved == True).count()
    since_24h = datetime.now(timezone.utc) - timedelta(hours=24)
    anomalies_today = db.query(Anomaly).filter(Anomaly.detected_at >= since_24h).count()
    severity_counts = {}
    for sev in ["critical", "high", "medium", "low"]:
        severity_counts[sev] = db.query(Anomaly).filter(Anomaly.severity == sev).count()
    top_nodes = db.query(Anomaly.node_id, sql_func.count(Anomaly.id).label("count")).group_by(
        Anomaly.node_id).order_by(sql_func.count(Anomaly.id).desc()).limit(10).all()
    return {
        "total_anomalies": total_anomalies, "unresolved_anomalies": unresolved,
        "resolved_anomalies": resolved, "anomalies_today": anomalies_today,
        "severity_counts": severity_counts,
        "top_attacked_nodes": [{"node": n, "count": c} for n, c in top_nodes],
        "model_params": 55201, "model_accuracy": 71.0
    }
