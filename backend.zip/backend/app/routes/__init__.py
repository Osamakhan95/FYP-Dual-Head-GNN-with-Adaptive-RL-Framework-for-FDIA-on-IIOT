from .auth import router as auth_router
from .admin import router as admin_router
from .model import router as model_router
from .live import router as live_router

__all__ = ["auth_router", "admin_router", "model_router", "live_router"]
