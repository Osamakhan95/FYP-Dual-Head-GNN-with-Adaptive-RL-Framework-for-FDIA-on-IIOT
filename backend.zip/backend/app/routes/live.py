"""
Live FDI Attack Detection via WebSocket.

Reads the SWaT dataset CSV row-by-row, runs each row through the DQN-GNN model,
and streams real-time predictions to connected frontend clients.

Protocol (JSON messages over WebSocket):
  Client → Server:
    {"action": "start"}                  — begin streaming predictions
    {"action": "start", "speed": 0.5}    — begin with 0.5s interval per row
    {"action": "stop"}                   — pause streaming
    {"action": "speed", "value": 1.0}    — change interval dynamically
    {"action": "jump", "row": 50000}     — jump to a specific row offset

  Server → Client:
    {"type": "prediction", "data": {...}}  — prediction result for one row
    {"type": "status", "data": {...}}      — connection / stream status
    {"type": "error", "message": "..."}    — error notification
"""

from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends
from sqlalchemy.orm import Session
from app.database import SessionLocal
from app.utils.model_loader import model_inference
from app.utils.auth import decode_access_token
from app.models import Anomaly
from app.models.user import User
import csv
import os
import json
import asyncio
from typing import Optional
from datetime import datetime, timezone

router = APIRouter(prefix="/model", tags=["Live Detection"])

# Path to the SWaT dataset
SWAT_CSV_PATH = os.path.join(
    os.path.dirname(__file__), "..", "..", "..",
    "test SWaT_Dataset_Attack_v0.csv"
)


def _parse_swat_csv():
    """
    Pre-parse the SWaT CSV headers once and return:
      header, sensor_indices, sensor_names, label_idx, data_start_line
    """
    with open(SWAT_CSV_PATH, "r", encoding="utf-8") as f:
        reader = csv.reader(f)
        all_header_rows = []
        for _ in range(3):
            try:
                all_header_rows.append(next(reader))
            except StopIteration:
                break

    # SWaT has 2 header rows — row[0] is empty commas, row[1] has sensor names
    header = [col.strip() for col in all_header_rows[1]]
    data_start = 2  # actual data starts at line index 2

    excluded = {"Timestamp", "Normal/Attack", "", "label", "Label"}
    sensor_indices = []
    sensor_names = []
    for i, col in enumerate(header):
        if col not in excluded:
            sensor_indices.append(i)
            sensor_names.append(col)

    label_idx = None
    for i, col in enumerate(header):
        if col in ("Normal/Attack", "label", "Label"):
            label_idx = i
            break

    # Find timestamp column
    ts_idx = None
    for i, col in enumerate(header):
        if col == "Timestamp":
            ts_idx = i
            break

    return header, sensor_indices, sensor_names, label_idx, ts_idx, data_start


def _authenticate_ws(token: str) -> Optional[User]:
    """Validate JWT token and return User or None."""
    payload = decode_access_token(token)
    if not payload:
        return None
    email = payload.get("sub")
    if not email:
        return None
    db = SessionLocal()
    try:
        user = db.query(User).filter(User.email == email).first()
        return user
    finally:
        db.close()


@router.websocket("/live")
async def live_detection(websocket: WebSocket):
    """
    WebSocket endpoint for live FDI attack detection.

    Query params:
        token: JWT access token for authentication
    """
    # --- Authentication ---
    token = websocket.query_params.get("token")
    if not token:
        await websocket.close(code=4001, reason="Missing authentication token")
        return

    user = _authenticate_ws(token)
    if not user:
        await websocket.close(code=4003, reason="Invalid or expired token")
        return

    await websocket.accept()

    # --- Check dataset exists ---
    if not os.path.exists(SWAT_CSV_PATH):
        await websocket.send_json({
            "type": "error",
            "message": f"SWaT dataset not found. Expected at: {SWAT_CSV_PATH}"
        })
        await websocket.close()
        return

    # Pre-parse headers
    try:
        header, sensor_indices, sensor_names, label_idx, ts_idx, data_start = _parse_swat_csv()
    except Exception as e:
        await websocket.send_json({"type": "error", "message": f"CSV parse error: {str(e)}"})
        await websocket.close()
        return

    # Count total lines for progress (cached)
    total_rows = 449919  # known SWaT dataset size — avoids slow line count

    await websocket.send_json({
        "type": "status",
        "data": {
            "state": "connected",
            "dataset": "SWaT_Dataset_Attack_v0",
            "total_rows": total_rows,
            "sensors": len(sensor_names),
            "message": "Connected. Send {\"action\": \"start\"} to begin live detection."
        }
    })

    # --- State ---
    streaming = False
    speed = 1.0  # seconds between predictions
    current_row = 0
    jump_to_row = None

    # Running tallies
    total_processed = 0
    total_attacks = 0
    total_normal = 0
    tp = tn = fp = fn = 0

    async def _stream_predictions():
        """Background task that reads CSV and streams predictions."""
        nonlocal streaming, current_row, jump_to_row
        nonlocal total_processed, total_attacks, total_normal
        nonlocal tp, tn, fp, fn

        total_eval = 0
        running_accuracy = None

        try:
            with open(SWAT_CSV_PATH, "r", encoding="utf-8") as f:
                reader = csv.reader(f)

                # Skip header rows
                for _ in range(data_start):
                    next(reader)

                # If jumping, skip rows
                if jump_to_row and jump_to_row > 0:
                    for _ in range(jump_to_row):
                        try:
                            next(reader)
                            current_row += 1
                        except StopIteration:
                            break
                    jump_to_row = None

                for row in reader:
                    if not streaming:
                        return

                    current_row += 1
                    total_processed += 1

                    # Parse sensor values
                    sensor_data = {}
                    for si, sn in zip(sensor_indices, sensor_names):
                        if si < len(row):
                            try:
                                sensor_data[sn] = float(row[si].strip())
                            except (ValueError, IndexError):
                                sensor_data[sn] = 0.0

                    # Parse actual label
                    actual_label = None
                    if label_idx is not None and label_idx < len(row):
                        raw_label = row[label_idx].strip()
                        try:
                            actual_label = int(float(raw_label))
                        except (ValueError, IndexError):
                            # SWaT uses "Normal" / "Attack" strings sometimes
                            if "attack" in raw_label.lower():
                                actual_label = 1
                            elif "normal" in raw_label.lower():
                                actual_label = 0

                    # Parse timestamp
                    timestamp_str = ""
                    if ts_idx is not None and ts_idx < len(row):
                        timestamp_str = row[ts_idx].strip()

                    # Run prediction
                    result = model_inference.predict(sensor_data)
                    is_attack = result.get("is_attack", False)
                    system_prob = result.get("system_probability", 0.0)
                    anomalies = result.get("anomalies", [])

                    if is_attack:
                        total_attacks += 1
                    else:
                        total_normal += 1

                    # Confusion matrix
                    correct = None
                    if actual_label is not None:
                        if actual_label == 1:
                            if is_attack:
                                tp += 1
                                correct = True
                            else:
                                fn += 1
                                correct = False
                        else:
                            if is_attack:
                                fp += 1
                                correct = False
                            else:
                                tn += 1
                                correct = True

                    total_eval = tp + tn + fp + fn
                    running_accuracy = round((tp + tn) / total_eval * 100, 1) if total_eval > 0 else None

                    # Save anomalies to DB (non-blocking)
                    if anomalies:
                        db = None
                        try:
                            db = SessionLocal()
                            for a in anomalies:
                                db.add(Anomaly(
                                    node_id=a["node_id"],
                                    confidence=a["confidence"],
                                    severity=a.get("severity", "medium")
                                ))
                            db.commit()
                        except Exception:
                            if db:
                                db.rollback()
                        finally:
                            if db:
                                db.close()

                    # Build sensor snapshot (top 10 most important)
                    key_sensors = ["FIT101", "LIT101", "AIT201", "FIT301", "LIT301",
                                   "AIT401", "LIT401", "AIT501", "FIT501", "PIT501"]
                    sensor_snapshot = {}
                    for s in key_sensors:
                        if s in sensor_data:
                            sensor_snapshot[s] = round(sensor_data[s], 4)

                    # Send prediction to client
                    payload = {
                        "type": "prediction",
                        "data": {
                            "row": current_row,
                            "timestamp": timestamp_str,
                            "is_attack": is_attack,
                            "system_probability": round(system_prob, 4),
                            "actual_label": actual_label,
                            "correct": correct,
                            "anomaly_count": len(anomalies),
                            "anomalies": [
                                {
                                    "node_id": a["node_id"],
                                    "confidence": round(a["confidence"], 4),
                                    "severity": a.get("severity", "medium"),
                                }
                                for a in anomalies
                            ],
                            "sensor_snapshot": sensor_snapshot,
                            "stats": {
                                "total_processed": total_processed,
                                "total_attacks": total_attacks,
                                "total_normal": total_normal,
                                "running_accuracy": running_accuracy,
                                "tp": tp, "tn": tn, "fp": fp, "fn": fn,
                                "progress": round(current_row / total_rows * 100, 2),
                            }
                        }
                    }

                    try:
                        await websocket.send_json(payload)
                    except Exception:
                        streaming = False
                        return

                    # Throttle
                    await asyncio.sleep(speed)

                # Reached end of dataset
                streaming = False
                await websocket.send_json({
                    "type": "status",
                    "data": {
                        "state": "finished",
                        "message": f"Completed all {current_row} rows.",
                        "total_processed": total_processed,
                        "total_attacks": total_attacks,
                        "total_normal": total_normal,
                        "running_accuracy": running_accuracy if total_eval > 0 else None,
                    }
                })

        except asyncio.CancelledError:
            pass
        except Exception as e:
            try:
                await websocket.send_json({"type": "error", "message": str(e)})
            except Exception:
                pass

    stream_task: Optional[asyncio.Task] = None

    try:
        while True:
            raw = await websocket.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                await websocket.send_json({"type": "error", "message": "Invalid JSON"})
                continue

            action = msg.get("action", "")

            if action == "start":
                if streaming:
                    await websocket.send_json({"type": "status", "data": {"state": "already_running"}})
                    continue

                # Optional speed override
                if "speed" in msg:
                    speed = max(0.1, min(5.0, float(msg["speed"])))

                # Optional row jump
                if "row" in msg:
                    jump_to_row = max(0, int(msg["row"]))
                    current_row = 0
                    total_processed = 0
                    total_attacks = 0
                    total_normal = 0
                    tp = tn = fp = fn = 0

                streaming = True
                stream_task = asyncio.create_task(_stream_predictions())

                await websocket.send_json({
                    "type": "status",
                    "data": {
                        "state": "streaming",
                        "speed": speed,
                        "message": f"Live detection started (interval: {speed}s)"
                    }
                })

            elif action == "stop":
                streaming = False
                if stream_task and not stream_task.done():
                    stream_task.cancel()
                    try:
                        await stream_task
                    except asyncio.CancelledError:
                        pass
                stream_task = None

                await websocket.send_json({
                    "type": "status",
                    "data": {
                        "state": "stopped",
                        "row": current_row,
                        "total_processed": total_processed,
                        "message": "Live detection paused."
                    }
                })

            elif action == "speed":
                speed = max(0.1, min(5.0, float(msg.get("value", 1.0))))
                await websocket.send_json({
                    "type": "status",
                    "data": {"state": "speed_changed", "speed": speed}
                })

            elif action == "reset":
                streaming = False
                if stream_task and not stream_task.done():
                    stream_task.cancel()
                    try:
                        await stream_task
                    except asyncio.CancelledError:
                        pass
                stream_task = None
                current_row = 0
                total_processed = 0
                total_attacks = 0
                total_normal = 0
                tp = tn = fp = fn = 0

                await websocket.send_json({
                    "type": "status",
                    "data": {"state": "reset", "message": "Session reset. Send start to begin again."}
                })

            else:
                await websocket.send_json({
                    "type": "error",
                    "message": f"Unknown action: {action}. Use start/stop/speed/reset."
                })

    except WebSocketDisconnect:
        streaming = False
        if stream_task and not stream_task.done():
            stream_task.cancel()
    except Exception as e:
        streaming = False
        if stream_task and not stream_task.done():
            stream_task.cancel()
        try:
            await websocket.send_json({"type": "error", "message": str(e)})
        except Exception:
            pass
